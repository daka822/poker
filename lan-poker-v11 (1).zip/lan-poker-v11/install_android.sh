#!/data/data/com.termux/files/usr/bin/bash
set -e
printf '\n=== LAN Poker: установка для Android / Termux ===\n\n'
if ! command -v pkg >/dev/null 2>&1; then
  echo 'Этот скрипт нужно запускать внутри Termux.'
  exit 1
fi
pkg update -y
pkg install -y python
chmod +x start_android.sh
printf '\nГотово. Для запуска используйте:\n  ./start_android.sh\n\n'
