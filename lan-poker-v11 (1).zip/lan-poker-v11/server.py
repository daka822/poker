#!/usr/bin/env python3
import base64
import hashlib
import hmac
import json
import os
import random
import secrets
import socket
import sys
import io
import sqlite3
import threading
import time
import urllib.parse
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from itertools import combinations
from pathlib import Path

BASE = Path(__file__).resolve().parent
VENDOR = BASE / 'vendor'
if VENDOR.exists():
    sys.path.insert(0, str(VENDOR))
try:
    import qrcode
    from qrcode.image.svg import SvgPathImage
except Exception:
    qrcode = None
    SvgPathImage = None
PUBLIC = BASE / 'public'
DB_PATH = BASE / 'poker.db'
PORT = int(os.environ.get('PORT', '8080'))
TURN_SECONDS = 15
SHOWDOWN_DELAY = 4.5
LOBBY_START_DELAY = 3.0
MAX_PLAYERS = 9
MIN_PLAYERS = 2
EMPTY_TABLE_GRACE = 8.0
NEW_TABLE_GRACE = 45.0
RELIEF_AMOUNT = 1500
RELIEF_COOLDOWN = 6 * 60
DEFAULT_TOURNAMENT_STACK = 3000
DEFAULT_LEVEL_HANDS = 5
MAIN_TABLE_ID = 'main'
GAME_LOG_LIMIT = 120
TERMS_VERSION = '2026-10-13-v1'

RANKS = '23456789TJQKA'
SUITS = 'shdc'
RANK_VALUE = {r: i + 2 for i, r in enumerate(RANKS)}
HAND_NAMES = {
    8: 'Стрит-флеш', 7: 'Каре', 6: 'Фулл-хаус', 5: 'Флеш',
    4: 'Стрит', 3: 'Сет', 2: 'Две пары', 1: 'Пара', 0: 'Старшая карта'
}
BETTING_PHASES = ('preflop', 'flop', 'turn', 'river')

lock = threading.RLock()
ADMIN_NICK = 'admin-' + secrets.token_hex(2)
ADMIN_PASSWORD = secrets.token_urlsafe(7)
admin_sessions = {}


def db_connect():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    now = int(time.time())
    with db_connect() as con:
        con.execute('''
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nick TEXT NOT NULL COLLATE NOCASE UNIQUE,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                balance INTEGER NOT NULL DEFAULT 1000,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                last_relief_at INTEGER NOT NULL DEFAULT 0
            )
        ''')
        cols = {row[1] for row in con.execute('PRAGMA table_info(accounts)').fetchall()}
        if 'last_relief_at' not in cols:
            con.execute('ALTER TABLE accounts ADD COLUMN last_relief_at INTEGER NOT NULL DEFAULT 0')
        if 'terms_version' not in cols:
            con.execute('ALTER TABLE accounts ADD COLUMN terms_version TEXT')
        if 'terms_accepted_at' not in cols:
            con.execute('ALTER TABLE accounts ADD COLUMN terms_accepted_at INTEGER NOT NULL DEFAULT 0')
        if 'privacy_accepted_at' not in cols:
            con.execute('ALTER TABLE accounts ADD COLUMN privacy_accepted_at INTEGER NOT NULL DEFAULT 0')
        con.execute('''
            CREATE TABLE IF NOT EXISTS permanent_tables (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                small_blind INTEGER NOT NULL,
                big_blind INTEGER NOT NULL,
                max_players INTEGER NOT NULL,
                password_salt TEXT,
                password_hash TEXT,
                host_code TEXT NOT NULL,
                mode TEXT NOT NULL DEFAULT 'cash',
                tournament_stack INTEGER NOT NULL DEFAULT 3000,
                level_hands INTEGER NOT NULL DEFAULT 5,
                created_at INTEGER NOT NULL
            )
        ''')
        con.execute('''
            CREATE TABLE IF NOT EXISTS account_stats (
                account_id INTEGER PRIMARY KEY,
                peak_balance INTEGER NOT NULL DEFAULT 0,
                hands_played INTEGER NOT NULL DEFAULT 0,
                hands_won INTEGER NOT NULL DEFAULT 0,
                total_won INTEGER NOT NULL DEFAULT 0,
                biggest_pot_won INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
            )
        ''')
        con.execute('''
            CREATE TABLE IF NOT EXISTS hand_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_key TEXT NOT NULL UNIQUE,
                account_id INTEGER,
                nick TEXT NOT NULL,
                table_id TEXT NOT NULL,
                table_name TEXT NOT NULL,
                hand_no INTEGER NOT NULL,
                hand_name TEXT NOT NULL,
                hand_category INTEGER NOT NULL,
                hand_score INTEGER NOT NULL,
                rank_json TEXT NOT NULL,
                hole_cards TEXT NOT NULL,
                board_cards TEXT NOT NULL,
                best_cards TEXT NOT NULL,
                pot_won INTEGER NOT NULL DEFAULT 0,
                achieved_at INTEGER NOT NULL
            )
        ''')
        con.execute('''
            CREATE TABLE IF NOT EXISTS game_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_id TEXT NOT NULL,
                table_name TEXT NOT NULL,
                hand_no INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                actor_nick TEXT,
                message TEXT NOT NULL
            )
        ''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_hand_records_score ON hand_records(hand_score DESC, achieved_at ASC)')
        con.execute('CREATE INDEX IF NOT EXISTS idx_hand_records_time ON hand_records(achieved_at DESC)')
        con.execute('CREATE INDEX IF NOT EXISTS idx_game_logs_table ON game_logs(table_id, id DESC)')
        con.execute('''
            INSERT OR IGNORE INTO account_stats(account_id, peak_balance, hands_played, hands_won, total_won, biggest_pot_won, updated_at)
            SELECT id, balance, 0, 0, 0, 0, ? FROM accounts
        ''', (now,))
        con.execute('''
            UPDATE account_stats
               SET peak_balance = MAX(peak_balance, COALESCE((SELECT balance FROM accounts WHERE accounts.id=account_stats.account_id), 0)),
                   updated_at = ?
        ''', (now,))
        con.commit()


def password_hash(password, salt=None):
    if salt is None:
        salt_bytes = secrets.token_bytes(16)
        salt = base64.b64encode(salt_bytes).decode('ascii')
    else:
        salt_bytes = base64.b64decode(salt.encode('ascii'))
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt_bytes, 180_000)
    return salt, base64.b64encode(digest).decode('ascii')


def find_account_by_nick(nick):
    target = str(nick or '').casefold()
    with db_connect() as con:
        exact = con.execute('SELECT * FROM accounts WHERE nick=? LIMIT 1', (nick,)).fetchone()
        if exact:
            return exact
        # SQLite NOCASE only fully handles ASCII; casefold in Python also protects Cyrillic nicks.
        for row in con.execute('SELECT * FROM accounts').fetchall():
            if str(row['nick']).casefold() == target:
                return row
    return None


def register_account(nick, password, accept_terms=False, accept_privacy=False):
    if len(password) < 4:
        raise ValueError('Пароль должен быть минимум 4 символа')
    if not accept_terms:
        raise ValueError('Для регистрации примите Пользовательское соглашение')
    if not accept_privacy:
        raise ValueError('Для регистрации дайте отдельное согласие на обработку данных аккаунта')
    if find_account_by_nick(nick):
        raise ValueError('Аккаунт с таким ником уже существует')
    now = int(time.time())
    salt, digest = password_hash(password)
    try:
        with db_connect() as con:
            cur = con.execute(
                'INSERT INTO accounts(nick,salt,password_hash,balance,created_at,updated_at,terms_version,terms_accepted_at,privacy_accepted_at) VALUES(?,?,?,?,?,?,?,?,?)',
                (nick, salt, digest, 1000, now, now, TERMS_VERSION, now, now)
            )
            account_id = cur.lastrowid
            con.execute(
                'INSERT OR REPLACE INTO account_stats(account_id,peak_balance,hands_played,hands_won,total_won,biggest_pot_won,updated_at) VALUES(?,?,?,?,?,?,?)',
                (account_id, 1000, 0, 0, 0, 0, now)
            )
            con.commit()
            return {'id': account_id, 'nick': nick, 'balance': 1000}
    except sqlite3.IntegrityError:
        raise ValueError('Аккаунт с таким ником уже существует')


def login_account(nick, password):
    row = find_account_by_nick(nick)
    if not row:
        raise ValueError('Аккаунт не найден')
    _, digest = password_hash(password, row['salt'])
    if not hmac.compare_digest(digest, row['password_hash']):
        raise ValueError('Неверный пароль')
    return {'id': row['id'], 'nick': row['nick'], 'balance': int(row['balance']), 'lastReliefAt': int(row['last_relief_at'] or 0)}


def claim_relief(nick, password):
    account = login_account(nick, password)
    if account_active(account['id']):
        raise ValueError('Сначала выйдите из игрового стола в главное меню')
    now = int(time.time())
    with db_connect() as con:
        row = con.execute('SELECT balance,last_relief_at FROM accounts WHERE id=?', (account['id'],)).fetchone()
        balance = int(row['balance'])
        last = int(row['last_relief_at'] or 0)
        if balance > 0:
            raise ValueError(f'Бонус доступен только при нулевом балансе. Сейчас: {balance}')
        remain = RELIEF_COOLDOWN - (now - last)
        if remain > 0:
            mins = remain // 60
            secs = remain % 60
            raise ValueError(f'Следующие {RELIEF_AMOUNT} фишек можно получить через {mins}:{secs:02d}')
        con.execute('UPDATE accounts SET balance=?, last_relief_at=?, updated_at=? WHERE id=?',
                    (RELIEF_AMOUNT, now, now, account['id']))
        con.commit()
    return {'balance': RELIEF_AMOUNT, 'nextAt': (now + RELIEF_COOLDOWN) * 1000}


def secure_text_equal(left, right):
    # compare_digest() rejects non-ASCII Python strings. Compare UTF-8 bytes instead
    # so Cyrillic/emoji in ordinary account credentials never crash admin detection.
    return hmac.compare_digest(str(left).encode('utf-8'), str(right).encode('utf-8'))


def is_admin_credentials(nick, password):
    return secure_text_equal(nick, ADMIN_NICK) and secure_text_equal(password, ADMIN_PASSWORD)


def save_account_balance(player):
    account_id = player.get('accountId')
    if not account_id or not player.get('persistBalance', True):
        return
    pending = player.pop('pendingAdminBalance', None)
    if pending is not None:
        player['chips'] = max(0, int(pending))
        player['allIn'] = False
    balance = max(0, int(player['chips']))
    now = int(time.time())
    with db_connect() as con:
        con.execute(
            'UPDATE accounts SET balance=?, updated_at=? WHERE id=?',
            (balance, now, account_id)
        )
        con.execute('''
            INSERT INTO account_stats(account_id,peak_balance,hands_played,hands_won,total_won,biggest_pot_won,updated_at)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(account_id) DO UPDATE SET
                peak_balance=MAX(account_stats.peak_balance, excluded.peak_balance),
                updated_at=excluded.updated_at
        ''', (account_id, balance, 0, 0, 0, 0, now))
        con.commit()


def admin_account_list():
    with db_connect() as con:
        rows = con.execute('SELECT id,nick,balance,updated_at FROM accounts ORDER BY nick COLLATE NOCASE').fetchall()
    result = []
    for row in rows:
        live = next(((g, p) for g in tables.values() for p in g['players']
                     if p.get('connected', True) and p.get('accountId') == row['id']), None)
        result.append({
            'id': row['id'], 'nick': row['nick'], 'balance': int(row['balance']),
            'table': live[0]['name'] if live else None,
            'playing': bool(live),
            'pendingBalance': live[1].get('pendingAdminBalance') if live else None,
        })
    guests = [
        {'playerId': p['id'], 'nick': p['nick'], 'chips': int(p['chips']),
         'tableId': g['id'], 'table': g['name'],
         'pendingBalance': p.get('pendingAdminBalance')}
        for g in tables.values() for p in g['players']
        if p.get('connected', True) and not p.get('accountId')
    ]
    return {'ok': True, 'accounts': result, 'guests': guests}


def set_admin_account_balance(account_id, amount):
    amount = int(amount)
    if not 0 <= amount <= 1_000_000_000:
        raise ValueError('Баланс должен быть от 0 до 1 000 000 000')
    with db_connect() as con:
        account = con.execute('SELECT id FROM accounts WHERE id=?', (account_id,)).fetchone()
        if not account:
            raise ValueError('Аккаунт не найден')
        now = int(time.time())
        con.execute('UPDATE accounts SET balance=?,updated_at=? WHERE id=?', (amount,now,account_id))
        con.execute('''INSERT INTO account_stats(account_id,peak_balance,updated_at)
                VALUES(?,?,?) ON CONFLICT(account_id) DO UPDATE SET
                peak_balance=MAX(account_stats.peak_balance,excluded.peak_balance),updated_at=excluded.updated_at''',
                (account_id, amount, now))
    for g in tables.values():
        for player in g['players']:
            if player.get('connected', True) and player.get('accountId') == account_id:
                if g.get('mode') == 'tournament':
                    # Tournament stacks never follow cash wallet changes.
                    continue
                if g['phase'] in BETTING_PHASES and player.get('inHand'):
                    player['pendingAdminBalance'] = amount
                else:
                    player['chips'] = amount
                    player['pendingAdminBalance'] = None
                    schedule_auto_start(g)
                silent_bump(g)
    return amount


def set_admin_guest_balance(table_id, player_id, amount):
    amount = int(amount)
    if not 0 <= amount <= 1_000_000_000:
        raise ValueError('Баланс должен быть от 0 до 1 000 000 000')
    g = tables.get(table_id)
    if not g or g.get('mode') != 'cash':
        raise ValueError('Гость найден не за cash-столом')
    player = next((p for p in g['players'] if p['id'] == player_id and p.get('connected', True) and not p.get('accountId')), None)
    if player is None:
        raise ValueError('Гость больше не за столом')
    if g['phase'] in BETTING_PHASES and player.get('inHand'):
        player['pendingAdminBalance'] = amount
    else:
        player['chips'] = amount
        player['pendingAdminBalance'] = None
        schedule_auto_start(g)
    silent_bump(g)
    return amount


def change_admin_password(account_id, new_password):
    if not 4 <= len(new_password) <= 128:
        raise ValueError('Новый пароль должен содержать от 4 до 128 символов')
    salt, digest = password_hash(new_password)
    with db_connect() as con:
        cur = con.execute('UPDATE accounts SET salt=?,password_hash=?,updated_at=? WHERE id=?',
                          (salt, digest, int(time.time()), account_id))
        if not cur.rowcount:
            raise ValueError('Аккаунт не найден')


def hand_score(rank):
    vals = list(rank)[:6] + [0] * max(0, 6 - len(rank))
    score = 0
    for v in vals[:6]:
        score = score * 15 + int(v)
    return score


def best_combo(cards):
    cards = list(cards)
    if len(cards) < 5:
        return None, []
    best_rank = None
    best_cards = []
    for comb in combinations(cards, 5):
        rank = rank5(list(comb))
        if best_rank is None or rank > best_rank:
            best_rank = rank
            best_cards = list(comb)
    return best_rank, best_cards


def add_game_log(g, event_type, message, actor_nick=None):
    with db_connect() as con:
        con.execute('''
            INSERT INTO game_logs(table_id,table_name,hand_no,created_at,event_type,actor_nick,message)
            VALUES(?,?,?,?,?,?,?)
        ''', (g['id'], g['name'], int(g.get('handNo', 0)), int(time.time()), event_type, actor_nick, str(message)))
        con.commit()


def record_hand_started(g):
    now = int(time.time())
    ids = sorted({p.get('accountId') for p in g['players'] if p.get('inHand') and p.get('accountId')})
    if not ids:
        return
    with db_connect() as con:
        for account_id in ids:
            row = con.execute('SELECT balance FROM accounts WHERE id=?', (account_id,)).fetchone()
            balance = int(row['balance']) if row else 0
            con.execute('''
                INSERT INTO account_stats(account_id,peak_balance,hands_played,hands_won,total_won,biggest_pot_won,updated_at)
                VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(account_id) DO UPDATE SET
                    peak_balance=MAX(account_stats.peak_balance, excluded.peak_balance),
                    hands_played=account_stats.hands_played+1,
                    updated_at=excluded.updated_at
            ''', (account_id, balance, 1, 0, 0, 0, now))
        con.commit()


def record_winnings(g, awards):
    now = int(time.time())
    with db_connect() as con:
        for i, amount in awards.items():
            if amount <= 0:
                continue
            p = g['players'][i]
            account_id = p.get('accountId')
            if not account_id:
                continue
            balance = max(0, int(p['chips']))
            con.execute('''
                INSERT INTO account_stats(account_id,peak_balance,hands_played,hands_won,total_won,biggest_pot_won,updated_at)
                VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(account_id) DO UPDATE SET
                    peak_balance=MAX(account_stats.peak_balance, excluded.peak_balance),
                    hands_won=account_stats.hands_won+1,
                    total_won=account_stats.total_won+excluded.total_won,
                    biggest_pot_won=MAX(account_stats.biggest_pot_won, excluded.biggest_pot_won),
                    updated_at=excluded.updated_at
            ''', (account_id, balance, 0, 1, int(amount), int(amount), now))
        con.commit()


def record_showdown_hands(g, live, awards):
    if len(g.get('board', [])) < 5:
        return
    now = int(time.time())
    with db_connect() as con:
        for i in live:
            p = g['players'][i]
            rank, combo = best_combo(p.get('cards', []) + g['board'])
            if not rank or not combo:
                continue
            key = f"{g['id']}:{g['handNo']}:{p['id']}"
            con.execute('''
                INSERT OR IGNORE INTO hand_records(
                    record_key,account_id,nick,table_id,table_name,hand_no,hand_name,hand_category,
                    hand_score,rank_json,hole_cards,board_cards,best_cards,pot_won,achieved_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ''', (
                key, p.get('accountId'), p['nick'], g['id'], g['name'], g['handNo'], HAND_NAMES[rank[0]], rank[0],
                hand_score(rank), json.dumps(list(rank)), json.dumps(p.get('cards', [])), json.dumps(g['board']),
                json.dumps(combo), int(awards.get(i, 0)), now
            ))
        con.commit()


def hand_record_dict(row):
    if not row:
        return None
    return {
        'nick': row['nick'], 'handName': row['hand_name'], 'handCategory': int(row['hand_category']),
        'holeCards': json.loads(row['hole_cards']), 'boardCards': json.loads(row['board_cards']),
        'bestCards': json.loads(row['best_cards']), 'potWon': int(row['pot_won']),
        'tableName': row['table_name'], 'handNo': int(row['hand_no']), 'achievedAt': int(row['achieved_at']) * 1000,
    }


def public_stats():
    with db_connect() as con:
        leaders = con.execute('''
            SELECT a.nick, a.balance, s.peak_balance, s.hands_played, s.hands_won, s.total_won
              FROM account_stats s JOIN accounts a ON a.id=s.account_id
             ORDER BY s.peak_balance DESC, a.balance DESC, a.nick COLLATE NOCASE ASC LIMIT 10
        ''').fetchall()
        all_time = con.execute('SELECT * FROM hand_records ORDER BY hand_score DESC, pot_won DESC, achieved_at ASC, id ASC LIMIT 1').fetchone()
        today = con.execute('''
            SELECT * FROM hand_records
             WHERE date(achieved_at, 'unixepoch', 'localtime') = date('now', 'localtime')
             ORDER BY hand_score DESC, pot_won DESC, achieved_at ASC, id ASC LIMIT 1
        ''').fetchone()
    return {
        'leaders': [
            {'nick': r['nick'], 'balance': int(r['balance']), 'peakBalance': int(r['peak_balance']),
             'handsPlayed': int(r['hands_played']), 'handsWon': int(r['hands_won']), 'totalWon': int(r['total_won'])}
            for r in leaders
        ],
        'allTimeHand': hand_record_dict(all_time),
        'todayHand': hand_record_dict(today),
    }


def recent_logs(table_id, limit=GAME_LOG_LIMIT):
    limit = max(1, min(GAME_LOG_LIMIT, int(limit)))
    with db_connect() as con:
        rows = con.execute('''
            SELECT id,hand_no,created_at,event_type,actor_nick,message
              FROM game_logs WHERE table_id=? ORDER BY id DESC LIMIT ?
        ''', (table_id, limit)).fetchall()
    rows = list(reversed(rows))
    return [
        {'id': int(r['id']), 'handNo': int(r['hand_no']), 'createdAt': int(r['created_at']) * 1000,
         'type': r['event_type'], 'actor': r['actor_nick'], 'message': r['message']}
        for r in rows
    ]


def fresh_game(table_id, name, *, small_blind=10, big_blind=20, max_players=9, table_password='',
               temporary=False, permanent=False, creator_host_code=None, mode='cash',
               tournament_stack=DEFAULT_TOURNAMENT_STACK, level_hands=DEFAULT_LEVEL_HANDS,
               password_salt=None, password_digest=None):
    if table_password and not password_digest:
        password_salt, password_digest = password_hash(table_password)
    mode = 'tournament' if mode == 'tournament' else 'cash'
    return {
        'id': table_id,
        'name': name,
        'version': 1,
        'players': [],
        'phase': 'lobby',
        'board': [],
        'pot': 0,
        'dealer': -1,
        'smallBlind': int(small_blind),
        'bigBlind': int(big_blind),
        'baseSmallBlind': int(small_blind),
        'baseBigBlind': int(big_blind),
        'maxPlayers': int(max_players),
        'passwordSalt': password_salt,
        'passwordHash': password_digest,
        'hostCode': creator_host_code or f'{random.randint(0, 999999):06d}',
        'temporary': bool(temporary),
        'permanent': bool(permanent),
        'mode': mode,
        'tournamentStack': max(100, int(tournament_stack)),
        'levelHands': max(1, int(level_hands)),
        'tournamentLevel': 1,
        'tournamentStarted': False,
        'tournamentWinner': None,
        'adminRevealCards': False,
        'createdAt': time.time(),
        'emptySince': time.time() if temporary else None,
        'everHadPlayers': False,
        'currentBet': 0,
        'minRaise': int(big_blind),
        'turn': None,
        'turnDeadline': None,
        'handNo': 0,
        'message': 'Ожидание игроков',
        'deck': [],
        'lastAggressor': None,
        'acted': set(),
        'showdown': None,
        'autoPlay': True,
        'hostPaused': False,
        'nextHandAt': None,
    }


tables = {}


def persist_table_config(g):
    if not g.get('permanent'):
        return
    with db_connect() as con:
        con.execute('''
            INSERT INTO permanent_tables(
                id,name,small_blind,big_blind,max_players,password_salt,password_hash,host_code,
                mode,tournament_stack,level_hands,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                name=excluded.name, small_blind=excluded.small_blind, big_blind=excluded.big_blind,
                max_players=excluded.max_players, password_salt=excluded.password_salt,
                password_hash=excluded.password_hash, host_code=excluded.host_code,
                mode=excluded.mode, tournament_stack=excluded.tournament_stack,
                level_hands=excluded.level_hands
        ''', (
            g['id'], g['name'], g['baseSmallBlind'], g['baseBigBlind'], g['maxPlayers'],
            g.get('passwordSalt'), g.get('passwordHash'), g['hostCode'], g['mode'],
            g['tournamentStack'], g['levelHands'], int(g.get('createdAt', time.time()))
        ))
        con.commit()


def delete_persistent_config(table_id):
    with db_connect() as con:
        con.execute('DELETE FROM permanent_tables WHERE id=?', (table_id,))
        con.commit()


def create_table(name='Стол 1', *, small_blind=10, big_blind=20, max_players=9, table_password='',
                 temporary=False, permanent=False, table_id=None, host_code=None, mode='cash',
                 tournament_stack=DEFAULT_TOURNAMENT_STACK, level_hands=DEFAULT_LEVEL_HANDS,
                 password_salt=None, password_digest=None):
    table_id = table_id or secrets.token_hex(3)
    host_code = host_code or f'{random.randint(0, 999999):06d}'
    tables[table_id] = fresh_game(
        table_id, name[:24] or 'Стол',
        small_blind=small_blind, big_blind=big_blind, max_players=max_players,
        table_password=table_password, temporary=temporary, permanent=permanent,
        creator_host_code=host_code, mode=mode, tournament_stack=tournament_stack,
        level_hands=level_hands, password_salt=password_salt, password_digest=password_digest
    )
    if permanent:
        persist_table_config(tables[table_id])
    return tables[table_id]


def load_permanent_tables():
    with db_connect() as con:
        rows = con.execute('SELECT * FROM permanent_tables ORDER BY created_at,id').fetchall()
    for row in rows:
        if row['id'] in tables:
            continue
        create_table(
            row['name'], small_blind=row['small_blind'], big_blind=row['big_blind'],
            max_players=row['max_players'], temporary=False, permanent=True, table_id=row['id'],
            host_code=row['host_code'], mode=row['mode'], tournament_stack=row['tournament_stack'],
            level_hands=row['level_hands'], password_salt=row['password_salt'], password_digest=row['password_hash']
        )
    if MAIN_TABLE_ID not in tables:
        create_table('Главный стол', temporary=False, permanent=True, table_id=MAIN_TABLE_ID)


def verify_table_password(g, password):
    if not g.get('passwordHash'):
        return True
    try:
        _, digest = password_hash(str(password or ''), g['passwordSalt'])
    except Exception:
        return False
    return hmac.compare_digest(digest, g['passwordHash'])


def registered_nick_exists(nick):
    return find_account_by_nick(nick) is not None


def normalize_nick(value):
    return ' '.join(str(value or '').strip().split())[:18]


def bump(g, msg=None):
    g['version'] += 1
    if msg is not None:
        g['message'] = msg

def silent_bump(g):
    g['message'] = ''
    bump(g)


def connected_players(g):
    return [p for p in g['players'] if p.get('connected', True)]


def eligible_connected(g):
    return [p for p in g['players'] if p.get('connected', True) and p['chips'] > 0]


def schedule_auto_start(g, delay=LOBBY_START_DELAY):
    if g['autoPlay'] and not g['hostPaused'] and g['phase'] in ('lobby', 'showdown') and len(eligible_connected(g)) >= 2:
        if g['nextHandAt'] is None:
            g['nextHandAt'] = time.time() + delay
    else:
        g['nextHandAt'] = None


def hand_details(cards):
    # Return (name, category, cards_that_make_the_hand).
    cards = list(cards)
    if not cards:
        return '', 0, []
    if len(cards) < 5:
        values = [RANK_VALUE[c[0]] for c in cards]
        counts = {v: values.count(v) for v in set(values)}
        fours = [v for v, n in counts.items() if n == 4]
        trips = [v for v, n in counts.items() if n == 3]
        pairs = sorted([v for v, n in counts.items() if n == 2], reverse=True)
        if fours:
            v = max(fours); return 'Каре', 7, [c for c in cards if RANK_VALUE[c[0]] == v]
        if trips:
            v = max(trips); return 'Сет', 3, [c for c in cards if RANK_VALUE[c[0]] == v]
        if len(pairs) >= 2:
            keep = set(pairs[:2]); return 'Две пары', 2, [c for c in cards if RANK_VALUE[c[0]] in keep]
        if pairs:
            v = pairs[0]; return 'Пара', 1, [c for c in cards if RANK_VALUE[c[0]] == v]
        return '', 0, []

    best_rank = None
    best_combo = None
    for comb in combinations(cards, 5):
        rank = rank5(list(comb))
        if best_rank is None or rank > best_rank:
            best_rank, best_combo = rank, list(comb)
    cat = best_rank[0]
    if cat == 0:
        highlights = []
    elif cat == 1:
        highlights = [c for c in best_combo if RANK_VALUE[c[0]] == best_rank[1]]
    elif cat == 2:
        keep = {best_rank[1], best_rank[2]}
        highlights = [c for c in best_combo if RANK_VALUE[c[0]] in keep]
    elif cat == 3:
        highlights = [c for c in best_combo if RANK_VALUE[c[0]] == best_rank[1]]
    elif cat == 7:
        highlights = [c for c in best_combo if RANK_VALUE[c[0]] == best_rank[1]]
    else:
        highlights = best_combo
    return HAND_NAMES[cat], cat, highlights


def partial_hand_name(cards):
    name, rank, _ = hand_details(cards)
    return name, rank


def admin_equities(g):
    if g['phase'] not in BETTING_PHASES or not g.get('adminRevealCards'):
        return {}
    eligible = [p for p in g['players'] if p.get('inHand') and not p['folded'] and len(p.get('cards', [])) == 2]
    if not eligible:
        return {}
    if len(eligible) == 1:
        return {eligible[0]['id']: 100.0}
    # Deal only UNKNOWN board cards. Folded and disconnected players' known cards
    # also stay removed from the random deck.
    known = set(g['board'])
    for p in g['players']:
        known.update(p.get('cards', []))
    key = (g['handNo'], tuple(g['board']), tuple((p['id'], tuple(p.get('cards', [])), p['folded'], p.get('inHand')) for p in g['players']))
    if g.get('_equityCacheKey') == key:
        return g['_equityCache']
    deck = [r+s for r in RANKS for s in SUITS if r+s not in known]
    need = 5 - len(g['board'])
    # Exact computation on river/turn, Monte Carlo on preflop/flop.
    if need <= 1:
        completions = combinations(deck, need)
    else:
        samples = 550 if need == 5 else 800
        rng = random.Random(secrets.randbits(64))
        completions = (rng.sample(deck, need) for _ in range(samples))
    scores = {p['id']: 0.0 for p in eligible}
    runs = 0
    for future in completions:
        board = g['board'] + list(future)
        ranks = [(p['id'], best7(p['cards'] + board)) for p in eligible]
        top = max(rank for _, rank in ranks)
        winners = [pid for pid, rank in ranks if rank == top]
        for pid in winners:
            scores[pid] += 1 / len(winners)
        runs += 1
    odds = {pid: round(100 * val / max(runs, 1), 1) for pid, val in scores.items()}
    g['_equityCacheKey'] = key
    g['_equityCache'] = odds
    return odds


def public_player(p, viewer_token, board, reveal_showdown=False, admin_reveal=False):
    own = p['token'] == viewer_token
    show = (reveal_showdown and not p['folded'] and p.get('inHand', False)) or (admin_reveal and bool(p.get('cards')))
    hand_name, hand_rank, highlights = ('', 0, [])
    if (own or show) and p.get('cards'):
        hand_name, hand_rank, highlights = hand_details(p['cards'] + list(board))
    return {
        'id': p['id'],
        'nick': p['nick'],
        'chips': p['chips'],
        'bet': p['bet'],
        'roundBet': p['roundBet'],
        'folded': p['folded'],
        'allIn': p['allIn'],
        'waiting': p.get('waiting', False),
        'inHand': p.get('inHand', False),
        'account': bool(p.get('accountId')),
        'cards': p['cards'] if (own or show) else [],
        'isYou': own,
        'handName': hand_name,
        'handRank': hand_rank,
        'highlightCards': highlights,
        'preAction': p.get('preAction') if own else None,
    }


def effective_max_target(g, idx):
    """Maximum round-bet target that at least one live opponent can cover.

    This prevents an unmatched oversized 'all-in' from temporarily moving the whole
    biggest stack into the pot. Excess chips simply stay in the player's stack.
    """
    p = g['players'][idx]
    own_max = p['roundBet'] + p['chips']
    opponent_caps = [
        op['roundBet'] + op['chips']
        for j, op in enumerate(g['players'])
        if j != idx and op.get('inHand', False) and not op['folded']
    ]
    if not opponent_caps:
        return p['roundBet']
    return min(own_max, max(opponent_caps))


def draw(g, n=1):
    return [g['deck'].pop() for _ in range(n)]


def next_live_index(g, start, include_allin=False):
    n = len(g['players'])
    if n == 0:
        return None
    for k in range(1, n + 1):
        i = (start + k) % n
        p = g['players'][i]
        if p.get('inHand', False) and not p['folded'] and (include_allin or not p['allIn']):
            return i
    return None


def contenders(g):
    return [i for i, p in enumerate(g['players']) if p.get('inHand', False) and not p['folded']]


def active_to_act(g):
    return [i for i, p in enumerate(g['players']) if p.get('inHand', False) and not p['folded'] and not p['allIn']]


def rank5(cards):
    vals = sorted([RANK_VALUE[c[0]] for c in cards], reverse=True)
    suits = [c[1] for c in cards]
    counts = {v: vals.count(v) for v in set(vals)}
    uniq = sorted(set(vals), reverse=True)
    if 14 in uniq:
        uniq.append(1)
    straight_high = None
    for i in range(len(uniq) - 4):
        run = uniq[i:i + 5]
        if run[0] - run[4] == 4:
            straight_high = run[0]
            break
    flush = len(set(suits)) == 1
    if flush and straight_high:
        return (8, straight_high)
    fours = sorted([v for v, c in counts.items() if c == 4], reverse=True)
    if fours:
        q = fours[0]
        k = max(v for v in vals if v != q)
        return (7, q, k)
    trips = sorted([v for v, c in counts.items() if c == 3], reverse=True)
    pairs = sorted([v for v, c in counts.items() if c >= 2], reverse=True)
    if trips:
        t = trips[0]
        pair = next((v for v in pairs if v != t), None)
        if pair is not None:
            return (6, t, pair)
    if flush:
        return (5, *vals)
    if straight_high:
        return (4, straight_high)
    if trips:
        t = trips[0]
        ks = sorted([v for v in vals if v != t], reverse=True)[:2]
        return (3, t, *ks)
    exact_pairs = sorted([v for v, c in counts.items() if c == 2], reverse=True)
    if len(exact_pairs) >= 2:
        a, b = exact_pairs[:2]
        k = max(v for v in vals if v not in (a, b))
        return (2, a, b, k)
    if len(exact_pairs) == 1:
        pair = exact_pairs[0]
        ks = sorted([v for v in vals if v != pair], reverse=True)[:3]
        return (1, pair, *ks)
    return (0, *vals)


def best7(cards):
    return max(rank5(list(c)) for c in combinations(cards, 5))


def save_all_account_balances(g):
    for p in g['players']:
        if p.get('accountId'):
            save_account_balance(p)


def settle_showdown(g):
    live = contenders(g)
    if not live:
        g['phase'] = 'showdown'
        g['turn'] = None
        g['turnDeadline'] = None
        g['showdown'] = {'winners': [], 'winningHands': [], 'contested': False, 'shownBy': [], 'text': 'Раздача завершена'}
        bump(g, 'Раздача завершена')
        schedule_auto_start(g, SHOWDOWN_DELAY)
        return

    awards = {}
    ranks = {}
    if len(live) == 1:
        winner = live[0]
        amount = g['pot']
        g['players'][winner]['chips'] += amount
        awards = {winner: amount}
        g['pot'] = 0
        text = f"{g['players'][winner]['nick']} забирает {amount} фишек"
        g['showdown'] = {'winners': [g['players'][winner]['id']], 'winningHands': [], 'contested': False, 'shownBy': [], 'text': text}
    else:
        while len(g['board']) < 5:
            if len(g['board']) == 0:
                g['board'] += draw(g, 3)
            else:
                g['board'] += draw(g, 1)
        ranks = {i: best7(g['players'][i]['cards'] + g['board']) for i in live}
        contrib = {i: p['bet'] for i, p in enumerate(g['players']) if p.get('inHand', False) and p['bet'] > 0}
        levels = sorted(set(contrib.values()))
        prev = 0
        awards = {i: 0 for i in live}
        for level in levels:
            involved = [i for i, c in contrib.items() if c >= level]
            pot_part = (level - prev) * len(involved)
            prev = level
            eligible = [i for i in involved if i in live]
            if not eligible:
                continue
            best = max(ranks[i] for i in eligible)
            winners = [i for i in eligible if ranks[i] == best]
            share, rem = divmod(pot_part, len(winners))
            for i in winners:
                awards[i] += share
            order = []
            idx = g['dealer']
            for _ in range(len(g['players'])):
                idx = (idx + 1) % len(g['players'])
                if idx in winners:
                    order.append(idx)
            for i in order[:rem]:
                awards[i] += 1
        for i, amount in awards.items():
            g['players'][i]['chips'] += amount
        g['pot'] = 0
        win_indices = [i for i, amount in awards.items() if amount > 0]
        text = '; '.join(
            f"{g['players'][i]['nick']} +{awards[i]} ({HAND_NAMES[ranks[i][0]]})" for i in win_indices
        ) or 'Ничья'
        winning_hands = []
        for i in win_indices:
            all_cards = g['players'][i]['cards'] + g['board']
            rank, combo = best_combo(all_cards)
            if rank and combo:
                hand_name, _, made_cards = hand_details(all_cards)
                # Presentation highlights only the cards that make the combination.
                # Pair -> 2 cards, two pair -> 4, trips -> 3, quads -> 4;
                # straights/flushes/full houses/straight flushes use the full five.
                if not made_cards and rank[0] == 0:
                    # For a high-card win there is no made combination; show only
                    # the actual highest card instead of lighting all five kickers.
                    high = max(combo, key=lambda c: RANK_VALUE[c[0]])
                    made_cards = [high]
                winning_hands.append({
                    'playerId': g['players'][i]['id'], 'nick': g['players'][i]['nick'],
                    'handName': hand_name or HAND_NAMES[rank[0]], 'cards': made_cards, 'award': int(awards[i])
                })
        g['showdown'] = {'winners': [g['players'][i]['id'] for i in win_indices], 'winningHands': winning_hands, 'contested': True, 'shownBy': [], 'text': text}

    if len(live) > 1 and len(g.get('board', [])) >= 5:
        record_showdown_hands(g, live, awards)
    record_winnings(g, awards)
    for i, amount in awards.items():
        if amount > 0:
            hand_name = ''
            if len(live) > 1 and len(g.get('board', [])) >= 5:
                rank, _ = best_combo(g['players'][i]['cards'] + g['board'])
                hand_name = f" · {HAND_NAMES[rank[0]]}" if rank else ''
            add_game_log(g, 'win', f"{g['players'][i]['nick']} выиграл {amount} фишек{hand_name}", g['players'][i]['nick'])

    g['phase'] = 'showdown'
    g['turn'] = None
    g['turnDeadline'] = None
    for p in g['players']:
        p['waiting'] = p.get('connected', True) and not p.get('inHand', False)
        p['preAction'] = None
    save_all_account_balances(g)
    if g.get('mode') == 'tournament' and g.get('tournamentStarted'):
        alive = [p for p in g['players'] if p.get('connected', True) and p['chips'] > 0]
        if len(alive) == 1 and len(g['players']) >= 2:
            g['tournamentWinner'] = alive[0]['nick']
            g['hostPaused'] = True
            g['nextHandAt'] = None
            g['showdown']['text'] += f" · Победитель турнира: {alive[0]['nick']}"
    bump(g, g['showdown']['text'])
    schedule_auto_start(g, 8.0 if len(live) == 1 else SHOWDOWN_DELAY)


def runout(g):
    if len(contenders(g)) <= 1:
        settle_showdown(g)
        return
    while len(g['board']) < 5:
        if len(g['board']) == 0:
            g['board'] += draw(g, 3)
        else:
            g['board'] += draw(g, 1)
    settle_showdown(g)


def should_runout(g):
    live = contenders(g)
    if len(live) <= 1:
        return True
    active = active_to_act(g)
    if not active:
        return True
    if len(active) == 1:
        i = active[0]
        return g['players'][i]['roundBet'] == g['currentBet']
    return False


def all_bets_matched(g):
    active = active_to_act(g)
    if len(contenders(g)) <= 1:
        return True
    if not active:
        return True
    return all(g['players'][i]['roundBet'] == g['currentBet'] and i in g['acted'] for i in active)


def set_turn(g, idx, msg=None):
    g['turn'] = idx
    g['turnDeadline'] = time.time() + TURN_SECONDS if idx is not None else None
    if msg is not None:
        bump(g, msg)


def advance_street(g):
    if len(contenders(g)) <= 1:
        settle_showdown(g)
        return
    if should_runout(g):
        runout(g)
        return

    if g['phase'] == 'preflop':
        g['board'] = draw(g, 3)
        g['phase'] = 'flop'
    elif g['phase'] == 'flop':
        g['board'] += draw(g, 1)
        g['phase'] = 'turn'
    elif g['phase'] == 'turn':
        g['board'] += draw(g, 1)
        g['phase'] = 'river'
    elif g['phase'] == 'river':
        settle_showdown(g)
        return

    for p in g['players']:
        if p.get('inHand', False):
            p['roundBet'] = 0
    g['currentBet'] = 0
    g['minRaise'] = g['bigBlind']
    g['acted'] = set()
    g['lastAggressor'] = None

    if should_runout(g):
        runout(g)
        return

    nxt = next_live_index(g, g['dealer'])
    if nxt is None:
        runout(g)
    else:
        set_turn(g, nxt, f"{g['phase'].upper()}: ход {g['players'][nxt]['nick']}")


def maybe_progress(g):
    if len(contenders(g)) <= 1:
        settle_showdown(g)
        return
    if should_runout(g):
        runout(g)
        return
    if all_bets_matched(g):
        advance_street(g)
        return
    start = g['turn'] if g['turn'] is not None else g['dealer']
    nxt = next_live_index(g, start)
    if nxt is None:
        advance_street(g)
    else:
        set_turn(g, nxt, f"Ход: {g['players'][nxt]['nick']}")


def post_blind(g, i, amount):
    p = g['players'][i]
    paid = min(amount, p['chips'])
    p['chips'] -= paid
    p['roundBet'] += paid
    p['bet'] += paid
    g['pot'] += paid
    if p['chips'] == 0:
        p['allIn'] = True


def prune_disconnected(g):
    if g['phase'] in BETTING_PHASES:
        return
    old_players = g['players']
    old_dealer_id = old_players[g['dealer']]['id'] if 0 <= g['dealer'] < len(old_players) else None
    g['players'] = [p for p in old_players if p.get('connected', True)]
    if not g['players']:
        g['dealer'] = -1
    elif old_dealer_id:
        g['dealer'] = next((i for i, p in enumerate(g['players']) if p['id'] == old_dealer_id), -1)
    else:
        g['dealer'] = -1


def start_hand(g):
    prune_disconnected(g)
    if len(eligible_connected(g)) < 2:
        raise ValueError('Нужно минимум 2 игрока с фишками')

    g['nextHandAt'] = None
    g['handNo'] += 1
    if g.get('mode') == 'tournament':
        g['tournamentStarted'] = True
        level = 1 + ((g['handNo'] - 1) // max(1, g.get('levelHands', DEFAULT_LEVEL_HANDS)))
        g['tournamentLevel'] = level
        factor = 2 ** (level - 1)
        g['smallBlind'] = max(1, g['baseSmallBlind'] * factor)
        g['bigBlind'] = max(g['smallBlind'] * 2, g['baseBigBlind'] * factor)
    g['deck'] = [r + s for r in RANKS for s in SUITS]
    random.SystemRandom().shuffle(g['deck'])
    g['board'] = []
    g['pot'] = 0
    g['showdown'] = None
    g['acted'] = set()
    g['phase'] = 'preflop'

    for p in g['players']:
        participates = p.get('connected', True) and p['chips'] > 0
        p.update({
            'cards': [], 'bet': 0, 'roundBet': 0,
            'folded': not participates, 'allIn': False,
            'inHand': participates, 'waiting': not participates, 'preAction': None,
        })

    n = len(g['players'])
    for _ in range(n):
        g['dealer'] = (g['dealer'] + 1) % n
        if g['players'][g['dealer']].get('inHand', False):
            break

    live_indices = [i for i, p in enumerate(g['players']) if p.get('inHand', False)]
    for i in live_indices:
        g['players'][i]['cards'] = draw(g, 2)

    if len(live_indices) == 2:
        sb = g['dealer']
        bb = next_live_index(g, sb, include_allin=True)
    else:
        sb = next_live_index(g, g['dealer'], include_allin=True)
        bb = next_live_index(g, sb, include_allin=True)

    post_blind(g, sb, g['smallBlind'])
    post_blind(g, bb, g['bigBlind'])
    g['currentBet'] = max(g['players'][sb]['roundBet'], g['players'][bb]['roundBet'])
    g['minRaise'] = g['bigBlind']
    g['lastAggressor'] = bb
    record_hand_started(g)
    add_game_log(g, 'hand_start', f"Раздача #{g['handNo']} началась · блайнды {g['smallBlind']}/{g['bigBlind']}")
    nxt = next_live_index(g, bb)
    if nxt is None:
        runout(g)
        return
    set_turn(g, nxt, f"Раздача #{g['handNo']}. Ход: {g['players'][nxt]['nick']}")


def perform_action(g, idx, action, amount=None, automatic=False):
    if g['turn'] != idx:
        raise ValueError('Сейчас не ваш ход')
    if g['phase'] not in BETTING_PHASES:
        raise ValueError('Сейчас нельзя делать ход')
    p = g['players'][idx]
    if not p.get('connected', True) and not automatic:
        raise ValueError('Игрок уже вышел')
    p['preAction'] = None
    to_call = max(0, g['currentBet'] - p['roundBet'])
    old_current_bet = g['currentBet']
    log_message = None
    event_type = action

    if action == 'fold':
        p['folded'] = True
        g['acted'].add(idx)
        log_message = f"{p['nick']}: пас" + (' · авто' if automatic else '')
    elif action == 'check':
        if to_call:
            raise ValueError('Нельзя чек — есть ставка')
        g['acted'].add(idx)
        log_message = f"{p['nick']}: чек" + (' · авто' if automatic else '')
    elif action == 'call':
        pay = min(to_call, p['chips'])
        p['chips'] -= pay
        p['roundBet'] += pay
        p['bet'] += pay
        g['pot'] += pay
        g['acted'].add(idx)
        if p['chips'] == 0:
            p['allIn'] = True
        log_message = f"{p['nick']}: колл {pay}"
    elif action == 'allin':
        max_target = effective_max_target(g, idx)
        target = min(p['roundBet'] + p['chips'], max_target)
        if target < p['roundBet']:
            target = p['roundBet']
        pay = target - p['roundBet']
        if pay <= 0 and to_call > 0:
            pay = min(to_call, p['chips'])
            target = p['roundBet'] + pay
        p['chips'] -= pay
        p['roundBet'] = target
        p['bet'] += pay
        g['pot'] += pay
        p['allIn'] = p['chips'] == 0
        if p['roundBet'] > g['currentBet']:
            raise_by = p['roundBet'] - g['currentBet']
            g['currentBet'] = p['roundBet']
            if raise_by >= g['minRaise']:
                g['minRaise'] = raise_by
                g['acted'] = {idx}
                g['lastAggressor'] = idx
            else:
                g['acted'].add(idx)
        else:
            g['acted'].add(idx)
        if p['allIn']:
            log_message = f"{p['nick']}: ALL-IN до {target} (+{pay})"
        else:
            log_message = f"{p['nick']}: максимальная эффективная ставка до {target} (+{pay})"
        event_type = 'allin'
    elif action == 'raise':
        target = int(amount or 0)
        if target <= g['currentBet']:
            raise ValueError('Рейз должен быть выше текущей ставки')
        add = target - p['roundBet']
        if add <= 0:
            raise ValueError('Некорректная сумма рейза')
        effective_max = effective_max_target(g, idx)
        if target > effective_max:
            raise ValueError(f'Максимальная эффективная ставка: до {effective_max}')
        if add > p['chips']:
            raise ValueError(f'Недостаточно фишек. Максимум до {p["roundBet"] + p["chips"]}')
        raise_by = target - g['currentBet']
        if raise_by < g['minRaise']:
            raise ValueError(f'Минимальный рейз: до {g["currentBet"] + g["minRaise"]}')
        p['chips'] -= add
        p['roundBet'] = target
        p['bet'] += add
        g['pot'] += add
        if p['chips'] == 0:
            p['allIn'] = True
        g['minRaise'] = raise_by
        g['currentBet'] = target
        g['acted'] = {idx}
        g['lastAggressor'] = idx
        log_message = f"{p['nick']}: рейз до {target} (+{target - old_current_bet})"
        event_type = 'raise'
    else:
        raise ValueError('Неизвестное действие')

    if log_message:
        add_game_log(g, event_type, log_message, p['nick'])
    maybe_progress(g)


def leave_or_kick(g, idx, reason='вышел', silent=False):
    p = g['players'][idx]
    if not p.get('connected', True):
        return
    p['connected'] = False
    p['waiting'] = False
    save_account_balance(p)
    if g['phase'] in BETTING_PHASES and p.get('inHand', False) and not p['folded']:
        p['folded'] = True
        if g['turn'] == idx:
            g['acted'].add(idx)
            maybe_progress(g)
        else:
            if len(contenders(g)) <= 1:
                settle_showdown(g)
            else:
                silent_bump(g) if silent else bump(g, f"{p['nick']} {reason}")
    else:
        prune_disconnected(g)
        silent_bump(g) if silent else bump(g, f"{p['nick']} {reason}")
        schedule_auto_start(g)


def account_active(account_id, excluding_token=None):
    for g in tables.values():
        for p in g['players']:
            if p.get('connected', True) and p.get('accountId') == account_id and p['token'] != excluding_token:
                return True
    return False


def find_player(g, token):
    return next((i for i, p in enumerate(g['players']) if p['token'] == token and p.get('connected', True)), None)


def state_for(g, token, *, is_admin=False, is_table_host=False):
    reveal_showdown = bool(g['phase'] == 'showdown' and g.get('showdown') and g['showdown'].get('contested'))
    admin_reveal = bool(is_admin and g.get('adminRevealCards'))
    visible = [(i, p) for i, p in enumerate(g['players']) if p.get('connected', True)]
    internal_to_visible = {internal: vis for vis, (internal, _) in enumerate(visible)}
    players = [public_player(p, token, g['board'], reveal_showdown or (g['phase']=='showdown' and p['id'] in g.get('showdown', {}).get('shownBy', [])), admin_reveal) for _, p in visible]
    internal_you = next((i for i, p in enumerate(g['players']) if p['token'] == token and p.get('connected', True)), None)
    you_idx = internal_to_visible.get(internal_you)
    turn_vis = internal_to_visible.get(g['turn'])
    dealer_vis = internal_to_visible.get(g['dealer'])

    board_highlights = []
    if g['phase'] == 'showdown' and g.get('showdown'):
        winning_cards = set()
        for wh in g['showdown'].get('winningHands', []):
            winning_cards.update(wh.get('cards', []))
        board_highlights = [c for c in g['board'] if c in winning_cards]
    elif internal_you is not None:
        p = g['players'][internal_you]
        if p.get('cards'):
            _, _, made = hand_details(p['cards'] + list(g['board']))
            board_highlights = [c for c in g['board'] if c in made]

    to_call = 0
    can = {}
    max_raise_target = 0
    if internal_you is not None and g['turn'] == internal_you and g['phase'] in BETTING_PHASES:
        p = g['players'][internal_you]
        to_call = max(0, g['currentBet'] - p['roundBet'])
        max_raise_target = effective_max_target(g, internal_you)
        min_target = g['currentBet'] + g['minRaise']
        can = {
            'fold': True,
            'check': to_call == 0,
            'call': to_call > 0 and p['chips'] > 0,
            'raise': max_raise_target >= min_target,
            'allin': p['chips'] > 0 and max_raise_target > p['roundBet'],
        }

    privileged = bool(is_admin or is_table_host)
    can_show = bool(g['phase']=='showdown' and g.get('showdown') and not g['showdown'].get('contested')
                    and internal_you is not None and g['players'][internal_you]['id'] in g['showdown'].get('winners', [])
                    and g['players'][internal_you]['id'] not in g['showdown'].get('shownBy', []))
    return {
        'tableId': g['id'], 'tableName': g['name'],
        'version': g['version'], 'phase': g['phase'], 'board': g['board'], 'boardHighlights': board_highlights,
        'pot': g['pot'], 'dealer': dealer_vis, 'smallBlind': g['smallBlind'], 'bigBlind': g['bigBlind'],
        'baseSmallBlind': g['baseSmallBlind'], 'baseBigBlind': g['baseBigBlind'],
        'maxPlayers': g['maxPlayers'], 'passworded': bool(g.get('passwordHash')),
        'permanent': bool(g.get('permanent')), 'mode': g.get('mode', 'cash'),
        'tournamentStack': g.get('tournamentStack'), 'levelHands': g.get('levelHands'),
        'tournamentLevel': g.get('tournamentLevel', 1), 'tournamentWinner': g.get('tournamentWinner'),
        'currentBet': g['currentBet'], 'minRaise': g['minRaise'], 'maxRaiseTarget': max_raise_target,
        'turn': turn_vis, 'handNo': g['handNo'],
        'message': g['message'], 'players': players, 'youIndex': you_idx, 'toCall': to_call, 'can': can,
        'preAction': g['players'][internal_you].get('preAction') if internal_you is not None else None,
        'showdown': g['showdown'], 'autoPlay': g['autoPlay'], 'hostPaused': g['hostPaused'],
        'nextHandAt': int(g['nextHandAt'] * 1000) if g['nextHandAt'] else None,
        'turnExpiresAt': int(g['turnDeadline'] * 1000) if g['turnDeadline'] else None,
        'turnSeconds': TURN_SECONDS,
        'isHost': privileged, 'isAdmin': bool(is_admin),
        'canGiveChips': bool(is_admin and g.get('mode') == 'cash'), 'canDeleteTable': bool(is_admin and g['id'] != MAIN_TABLE_ID),
        'canRevealCards': bool(is_admin), 'adminRevealCards': bool(admin_reveal),
        'canCreatePermanentTables': bool(is_admin),
        'canShowCards': can_show,
        'adminOdds': admin_equities(g) if admin_reveal else {},
    }


def table_summary(g):
    return {
        'id': g['id'], 'name': g['name'], 'players': len(connected_players(g)),
        'maxPlayers': g['maxPlayers'], 'phase': g['phase'], 'handNo': g['handNo'],
        'paused': g['hostPaused'], 'blinds': f"{g['smallBlind']}/{g['bigBlind']}",
        'passworded': bool(g.get('passwordHash')), 'temporary': bool(g.get('temporary')),
        'permanent': bool(g.get('permanent')), 'mode': g.get('mode', 'cash'),
        'tournamentLevel': g.get('tournamentLevel', 1),
    }


def table_host_ok(g, code):
    code = str(code or '')
    return bool(code) and secure_text_equal(code, g.get('hostCode', ''))


def prepare_table_close(g):
    # If an active hand is aborted by table deletion, return every unresolved
    # contribution to its owner so persistent account balances cannot lose chips.
    if g['phase'] in BETTING_PHASES:
        for p in g['players']:
            contribution = max(0, int(p.get('bet', 0)))
            if contribution:
                p['chips'] += contribution
                p['bet'] = 0
                p['roundBet'] = 0
        g['pot'] = 0
    save_all_account_balances(g)


def auto_tick_loop():
    while True:
        time.sleep(0.2)
        with lock:
            now = time.time()
            for table_id, g in list(tables.items()):
                try:
                    live_count = len(connected_players(g))
                    if live_count:
                        g['everHadPlayers'] = True
                        g['emptySince'] = None
                    elif g.get('temporary'):
                        if g.get('emptySince') is None:
                            g['emptySince'] = now
                        grace = EMPTY_TABLE_GRACE if g.get('everHadPlayers') else NEW_TABLE_GRACE
                        if now - g['emptySince'] >= grace:
                            prepare_table_close(g)
                            for tok, sess in list(admin_sessions.items()):
                                if sess.get('tableId') == table_id:
                                    admin_sessions.pop(tok, None)
                            tables.pop(table_id, None)
                            continue

                    if g['phase'] in BETTING_PHASES and g['turn'] is not None:
                        idx = g['turn']
                        p = g['players'][idx]
                        if p.get('connected', True) and p.get('preAction') == 'checkfold':
                            p['preAction'] = None
                            to_call = max(0, g['currentBet'] - p['roundBet'])
                            auto_action = 'fold' if to_call > 0 else 'check'
                            perform_action(g, idx, auto_action, automatic=True)
                            continue

                    if g['phase'] in BETTING_PHASES and g['turn'] is not None and g['turnDeadline'] and now >= g['turnDeadline']:
                        idx = g['turn']
                        p = g['players'][idx]
                        if not p.get('connected', True):
                            p['folded'] = True
                            maybe_progress(g)
                        else:
                            to_call = max(0, g['currentBet'] - p['roundBet'])
                            auto_action = 'fold' if to_call > 0 else 'check'
                            nick = p['nick']
                            perform_action(g, idx, auto_action, automatic=True)
                            if g['phase'] in BETTING_PHASES:
                                g['message'] = f"{nick}: авто-{'пас' if auto_action == 'fold' else 'чек'} по таймеру"
                                g['version'] += 1

                    if g['phase'] in ('lobby', 'showdown'):
                        schedule_auto_start(g, SHOWDOWN_DELAY if g['phase'] == 'showdown' else LOBBY_START_DELAY)
                        if g['nextHandAt'] and now >= g['nextHandAt']:
                            if len(eligible_connected(g)) >= 2 and not g['hostPaused']:
                                try:
                                    start_hand(g)
                                except ValueError:
                                    g['nextHandAt'] = None
                            else:
                                g['nextHandAt'] = None
                except Exception as exc:
                    print('tick error:', exc)


class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        # Never expose poker.db, password hashes, or server.py via ../ requests.
        path = urllib.parse.unquote(urllib.parse.urlparse(path).path)
        rel = path.lstrip('/') or 'index.html'
        root = PUBLIC.resolve()
        target = (root / rel).resolve()
        if target != root and root not in target.parents:
            return str(root / '_not_found_')
        return str(target)

    def log_message(self, fmt, *args):
        pass

    def send_json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def is_local_host_request(self):
        try:
            addr = str(self.client_address[0])
        except Exception:
            return False
        return addr in ('127.0.0.1', '::1') or addr.startswith('127.')

    def read_json(self):
        n = int(self.headers.get('Content-Length', '0'))
        raw = self.rfile.read(n) if n else b'{}'
        return json.loads(raw or b'{}')

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path == '/api/host-info':
            if not self.is_local_host_request():
                return self.send_json({'ok': False, 'error': 'Доступно только на телефоне-хосте'}, 403)
            urls = [f'http://{ip}:{PORT}' for ip in local_ipv4_addresses()]
            return self.send_json({
                'ok': True,
                'version': 'v11',
                'localUrl': f'http://127.0.0.1:{PORT}',
                'friendUrls': urls,
                'adminNick': ADMIN_NICK,
                'adminPassword': ADMIN_PASSWORD,
                'dbPath': str(DB_PATH),
            })
        if u.path == '/host-qr.svg':
            if not self.is_local_host_request():
                return self.send_json({'ok': False, 'error': 'Доступно только на телефоне-хосте'}, 403)
            q = urllib.parse.parse_qs(u.query)
            target = q.get('url', [''])[0]
            if not target.startswith('http://') or qrcode is None:
                return self.send_json({'ok': False, 'error': 'QR недоступен'}, 400)
            image = qrcode.make(target, image_factory=SvgPathImage, box_size=8, border=2)
            buf = io.BytesIO()
            image.save(buf)
            data = buf.getvalue()
            self.send_response(200)
            self.send_header('Content-Type', 'image/svg+xml; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if u.path == '/api/admin/accounts':
            q = urllib.parse.parse_qs(u.query)
            token = q.get('token', [''])[0]
            table_id = q.get('tableId', [''])[0]
            with lock:
                if token not in admin_sessions or admin_sessions[token].get('tableId') != table_id or table_id not in tables:
                    return self.send_json({'ok':False,'error':'Доступ только главному администратору'}, 403)
                return self.send_json(admin_account_list())
        if u.path == '/api/stats':
            return self.send_json(public_stats())
        if u.path == '/api/logs':
            q = urllib.parse.parse_qs(u.query)
            token = q.get('token', [''])[0]
            table_id = q.get('tableId', [''])[0]
            with lock:
                g = tables.get(table_id)
                if not g:
                    return self.send_json({'ok': False, 'error': 'Стол не найден'}, 404)
                is_admin = token in admin_sessions and admin_sessions[token].get('tableId') == table_id
                idx = find_player(g, token)
                if idx is None and not is_admin:
                    return self.send_json({'ok': False, 'error': 'Сессия не найдена'}, 401)
                return self.send_json({'ok': True, 'logs': recent_logs(table_id)})
        if u.path == '/api/tables':
            with lock:
                return self.send_json({'tables': [table_summary(g) for g in tables.values()]})
        if u.path == '/api/state':
            q = urllib.parse.parse_qs(u.query)
            token = q.get('token', [''])[0]
            table_id = q.get('tableId', [''])[0]
            host_code = q.get('hostCode', [''])[0]
            with lock:
                g = tables.get(table_id)
                if not g:
                    return self.send_json({'ok': False, 'error': 'Стол не найден'}, 404)
                is_admin = token in admin_sessions and admin_sessions[token].get('tableId') == table_id
                idx = find_player(g, token)
                if idx is None and not is_admin:
                    return self.send_json({'ok': False, 'error': 'Сессия игрока не найдена'}, 401)
                if idx is not None:
                    g['players'][idx]['lastSeen'] = time.time()
                result = state_for(g, token, is_admin=is_admin, is_table_host=table_host_ok(g, host_code))
                return self.send_json(result)
        return super().do_GET()

    def do_POST(self):
        try:
            body = self.read_json()
            path = urllib.parse.urlparse(self.path).path
            with lock:
                if path == '/api/table/create':
                    name = ' '.join(str(body.get('name', '')).strip().split())[:24] or f'Стол {len(tables)+1}'
                    sb = max(1, int(body.get('smallBlind', 10)))
                    bb = max(sb * 2, int(body.get('bigBlind', max(20, sb * 2))))
                    max_players = max(MIN_PLAYERS, min(MAX_PLAYERS, int(body.get('maxPlayers', 9))))
                    password = str(body.get('tablePassword', ''))[:64]
                    mode = 'tournament' if body.get('mode') == 'tournament' else 'cash'
                    tournament_stack = max(100, min(1_000_000, int(body.get('tournamentStack', DEFAULT_TOURNAMENT_STACK))))
                    level_hands = max(1, min(100, int(body.get('levelHands', DEFAULT_LEVEL_HANDS))))
                    g = create_table(name, small_blind=sb, big_blind=bb, max_players=max_players,
                                     table_password=password, temporary=True, mode=mode,
                                     tournament_stack=tournament_stack, level_hands=level_hands)
                    return self.send_json({'ok': True, 'table': table_summary(g), 'hostCode': g['hostCode']})

                if path == '/api/account/relief':
                    nick = normalize_nick(body.get('nick', ''))
                    if not nick:
                        raise ValueError('Введите ник аккаунта')
                    result = claim_relief(nick, str(body.get('password', '')))
                    return self.send_json({'ok': True, **result})

                if path == '/api/join':
                    table_id = str(body.get('tableId', ''))
                    g = tables.get(table_id)
                    if not g:
                        raise ValueError('Выберите существующий стол')

                    mode = str(body.get('mode', 'guest'))
                    nick = normalize_nick(body.get('nick', ''))
                    password = str(body.get('password', ''))
                    if mode == 'login' and is_admin_credentials(nick, password):
                        token = secrets.token_urlsafe(24)
                        admin_sessions[token] = {'tableId': table_id, 'createdAt': time.time()}
                        return self.send_json({
                            'ok': True, 'token': token, 'tableId': table_id,
                            'account': True, 'admin': True, 'chips': 0,
                        })

                    if not verify_table_password(g, body.get('tablePassword', '')):
                        raise ValueError('Неверный пароль стола')
                    if len(connected_players(g)) >= g['maxPlayers']:
                        raise ValueError(f"Стол заполнен (максимум {g['maxPlayers']})")
                    if not nick:
                        raise ValueError('Введите ник')

                    account = None
                    if mode == 'register':
                        account = register_account(nick, password, bool(body.get('acceptTerms')), bool(body.get('acceptPrivacy')))
                        nick = account['nick']
                    elif mode == 'login':
                        account = login_account(nick, password)
                        nick = account['nick']
                        if account_active(account['id']):
                            raise ValueError('Этот аккаунт уже играет за другим столом')
                    elif mode == 'guest':
                        if registered_nick_exists(nick):
                            raise ValueError('Этот ник зарегистрирован. Войдите в аккаунт с паролем или выберите другой гостевой ник')
                    else:
                        raise ValueError('Неизвестный режим входа')

                    if any(p.get('connected', True) and p['nick'].lower() == nick.lower() for p in g['players']):
                        raise ValueError('Такой ник уже занят за этим столом')

                    token = secrets.token_urlsafe(24)
                    pid = secrets.token_hex(5)
                    active_hand = g['phase'] in BETTING_PHASES
                    tournament = g.get('mode') == 'tournament'
                    late_tournament = bool(tournament and g.get('tournamentStarted'))
                    chips = (0 if late_tournament else g['tournamentStack']) if tournament else (int(account['balance']) if account else 1000)
                    p = {
                        'id': pid, 'token': token, 'nick': nick, 'chips': chips,
                        'cards': [], 'bet': 0, 'roundBet': 0,
                        'folded': active_hand or late_tournament, 'allIn': False,
                        'inHand': False, 'waiting': active_hand or late_tournament,
                        'connected': True, 'lastSeen': time.time(),
                        'accountId': account['id'] if account else None,
                        'persistBalance': not tournament, 'preAction': None,
                    }
                    g['players'].append(p)
                    g['everHadPlayers'] = True
                    g['emptySince'] = None
                    if late_tournament:
                        bump(g, f'{nick} подключился наблюдателем: турнир уже начался')
                    elif active_hand:
                        bump(g, f'{nick} присоединился и ждёт следующую раздачу')
                    else:
                        bump(g, f'{nick} присоединился')
                        schedule_auto_start(g)
                    return self.send_json({
                        'ok': True, 'token': token, 'tableId': table_id,
                        'account': bool(account), 'admin': False, 'chips': chips,
                    })

                table_id = str(body.get('tableId', ''))
                g = tables.get(table_id)
                if not g:
                    raise ValueError('Стол не найден')
                token = str(body.get('token', ''))
                is_admin = token in admin_sessions and admin_sessions[token].get('tableId') == table_id
                idx = find_player(g, token)
                if idx is None and not is_admin:
                    raise ValueError('Сессия игрока не найдена')
                if idx is not None:
                    g['players'][idx]['lastSeen'] = time.time()
                is_table_host = table_host_ok(g, body.get('hostCode', ''))
                can_manage = is_admin or is_table_host

                if path == '/api/host':
                    if not can_manage:
                        raise ValueError('Неверный код ведущего этого стола')
                    return self.send_json({'ok': True, 'isHost': True, 'isAdmin': is_admin})

                if path == '/api/leave':
                    if is_admin:
                        admin_sessions.pop(token, None)
                    else:
                        leave_or_kick(g, idx, 'вышел из игры')
                    return self.send_json({'ok': True})

                if path == '/api/table/delete':
                    if not is_admin:
                        raise ValueError('Удалять столы может только администратор сервера')
                    if g['id'] == MAIN_TABLE_ID:
                        raise ValueError('Главный стол нельзя удалить')
                    prepare_table_close(g)
                    if g.get('permanent'):
                        delete_persistent_config(g['id'])
                    for p in g['players']:
                        p['connected'] = False
                    for tok, sess in list(admin_sessions.items()):
                        if sess.get('tableId') == table_id:
                            admin_sessions.pop(tok, None)
                    tables.pop(table_id, None)
                    return self.send_json({'ok': True})

                if path == '/api/admin/account/update':
                    if not is_admin:
                        raise ValueError('Доступ только главному администратору')
                    account_id = int(body.get('accountId', 0))
                    action = body.get('action')
                    if action == 'password':
                        change_admin_password(account_id, str(body.get('password', '')))
                    elif action == 'balance':
                        set_admin_account_balance(account_id, body.get('amount', 0))
                    else:
                        raise ValueError('Неизвестное действие')
                    return self.send_json({'ok': True})

                if path == '/api/admin/guest/balance':
                    if not is_admin:
                        raise ValueError('Доступ только главному администратору')
                    set_admin_guest_balance(str(body.get('targetTableId', '')), str(body.get('playerId','')), body.get('amount', 0))
                    return self.send_json({'ok': True})

                if path == '/api/show-cards':
                    if is_admin or idx is None or g['phase'] != 'showdown' or not g.get('showdown'):
                        raise ValueError('Показать карты сейчас нельзя')
                    if g['showdown'].get('contested') or g['players'][idx]['id'] not in g['showdown']['winners']:
                        raise ValueError('Показать карты может только победитель без вскрытия')
                    shown = g['showdown'].setdefault('shownBy', [])
                    if g['players'][idx]['id'] not in shown:
                        shown.append(g['players'][idx]['id'])
                        # Player voluntarily showed their cards: this is gameplay, not an admin action.
                        add_game_log(g, 'show_cards', f"{g['players'][idx]['nick']} показал свои карты", g['players'][idx]['nick'])
                        bump(g, f"{g['players'][idx]['nick']} показывает карты")
                    return self.send_json({'ok': True})

                if path == '/api/admin/reveal':
                    if not is_admin:
                        raise ValueError('Просмотр скрытых карт доступен только главному администратору')
                    g['adminRevealCards'] = bool(body.get('enabled'))
                    silent_bump(g)
                    return self.send_json({'ok': True, 'enabled': g['adminRevealCards']})

                if path == '/api/admin/table/create':
                    if not is_admin:
                        raise ValueError('Постоянные столы создаёт только главный администратор')
                    name = ' '.join(str(body.get('name', '')).strip().split())[:24] or f'Админ стол {len(tables)+1}'
                    sb = max(1, int(body.get('smallBlind', 10)))
                    bb = max(sb * 2, int(body.get('bigBlind', max(20, sb * 2))))
                    max_players = max(MIN_PLAYERS, min(MAX_PLAYERS, int(body.get('maxPlayers', 9))))
                    password = str(body.get('tablePassword', ''))[:64]
                    mode = 'tournament' if body.get('mode') == 'tournament' else 'cash'
                    tournament_stack = max(100, min(1_000_000, int(body.get('tournamentStack', DEFAULT_TOURNAMENT_STACK))))
                    level_hands = max(1, min(100, int(body.get('levelHands', DEFAULT_LEVEL_HANDS))))
                    permanent = bool(body.get('permanent', True))
                    new_g = create_table(name, small_blind=sb, big_blind=bb, max_players=max_players,
                                         table_password=password, temporary=not permanent, permanent=permanent,
                                         mode=mode, tournament_stack=tournament_stack, level_hands=level_hands)
                    return self.send_json({'ok': True, 'table': table_summary(new_g), 'hostCode': new_g['hostCode']})

                if path == '/api/start':
                    if not can_manage:
                        raise ValueError('Только ведущий стола или администратор может начать раздачу')
                    if g['phase'] in BETTING_PHASES:
                        raise ValueError('Раздача уже идёт')
                    start_hand(g)
                    return self.send_json({'ok': True})

                if path == '/api/autoplay':
                    if not can_manage:
                        raise ValueError('Только ведущий стола или администратор может управлять автоигрой')
                    paused = bool(body.get('paused'))
                    g['hostPaused'] = paused
                    g['nextHandAt'] = None
                    silent_bump(g)
                    if not paused:
                        schedule_auto_start(g)
                    return self.send_json({'ok': True, 'paused': paused})

                if path == '/api/settings':
                    if not can_manage:
                        raise ValueError('Только ведущий стола или администратор может менять настройки')
                    if g['phase'] in BETTING_PHASES:
                        raise ValueError('Настройки меняются между раздачами')
                    sb = max(1, int(body.get('smallBlind', 10)))
                    bb = max(sb * 2, int(body.get('bigBlind', 20)))
                    g['smallBlind'] = sb
                    g['bigBlind'] = bb
                    g['baseSmallBlind'] = sb
                    g['baseBigBlind'] = bb
                    if g.get('permanent'):
                        persist_table_config(g)
                    silent_bump(g)
                    return self.send_json({'ok': True})

                if path == '/api/chips':
                    if not is_admin:
                        raise ValueError('Баланс вручную меняет только администратор сервера')
                    if g.get('mode') == 'tournament':
                        raise ValueError('В турнире стартовые фишки фиксированы и не меняют баланс аккаунта')
                    if g['phase'] in BETTING_PHASES:
                        raise ValueError('Фишки выдаются между раздачами')
                    pid = str(body.get('playerId', ''))
                    amount = max(0, int(body.get('amount', 0)))
                    player = next((p for p in g['players'] if p['id'] == pid and p.get('connected', True)), None)
                    if not player:
                        raise ValueError('Игрок не найден')
                    player['chips'] = amount
                    save_account_balance(player)
                    silent_bump(g)
                    schedule_auto_start(g)
                    return self.send_json({'ok': True})

                if path == '/api/kick':
                    if not can_manage:
                        raise ValueError('Только ведущий стола или администратор может выгонять игроков')
                    pid = str(body.get('playerId', ''))
                    kick_idx = next((i for i, p in enumerate(g['players']) if p['id'] == pid and p.get('connected', True)), None)
                    if kick_idx is None:
                        raise ValueError('Игрок не найден')
                    nick = g['players'][kick_idx]['nick']
                    leave_or_kick(g, kick_idx, 'вышел', silent=True)
                    return self.send_json({'ok': True, 'nick': nick})

                if path == '/api/preaction':
                    if is_admin or idx is None:
                        raise ValueError('Администратор наблюдает и не участвует в раздаче')
                    p = g['players'][idx]
                    value = body.get('preAction')
                    if value not in (None, '', 'checkfold'):
                        raise ValueError('Неизвестная авто-кнопка')
                    if value == 'checkfold':
                        if g['phase'] not in BETTING_PHASES or not p.get('inHand') or p.get('folded') or p.get('allIn'):
                            raise ValueError('Сейчас авто чек/фолд недоступен')
                        if g['turn'] == idx:
                            raise ValueError('Ваш ход уже начался — используйте обычные кнопки')
                        p['preAction'] = 'checkfold'
                    else:
                        p['preAction'] = None
                    bump(g)
                    return self.send_json({'ok': True, 'preAction': p.get('preAction')})

                if path == '/api/action':
                    if is_admin or idx is None:
                        raise ValueError('Администратор наблюдает и не участвует в раздаче')
                    perform_action(g, idx, body.get('action'), body.get('amount'))
                    return self.send_json({'ok': True})

                raise ValueError('Неизвестный запрос')
        except Exception as exc:
            self.send_json({'ok': False, 'error': str(exc)}, 400)

def local_ipv4_addresses():
    """Return usable LAN/hotspot IPv4 addresses without requiring Internet."""
    found = []

    def add(value):
        value = str(value or '').strip()
        if not value or value.startswith('127.') or value == '0.0.0.0':
            return
        if value not in found:
            found.append(value)

    # Best path on Linux/Android/Termux: ask each interface for its IPv4.
    try:
        import fcntl
        import struct
        SIOCGIFADDR = 0x8915
        for _, ifname in socket.if_nameindex():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                req = struct.pack('256s', ifname[:15].encode('utf-8'))
                res = fcntl.ioctl(sock.fileno(), SIOCGIFADDR, req)
                sock.close()
                add(socket.inet_ntoa(res[20:24]))
            except Exception:
                pass
    except Exception:
        pass

    # Fallbacks work even when there is no real Internet connection as long as
    # the OS has a route for Wi-Fi/hotspot. UDP connect sends no packet here.
    for target in ('8.8.8.8', '1.1.1.1', '192.168.1.1'):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect((target, 80))
            add(sock.getsockname()[0])
            sock.close()
        except Exception:
            pass

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(info[4][0])
    except Exception:
        pass

    # Put ordinary private LAN addresses first.
    def score(ip):
        if ip.startswith('192.168.'):
            return (0, ip)
        if ip.startswith('10.'):
            return (1, ip)
        if ip.startswith('172.'):
            try:
                second = int(ip.split('.')[1])
                if 16 <= second <= 31:
                    return (2, ip)
            except Exception:
                pass
        if ip.startswith('169.254.'):
            return (9, ip)
        return (5, ip)

    return sorted(found, key=score)


def local_ip():
    ips = local_ipv4_addresses()
    return ips[0] if ips else '127.0.0.1'


if __name__ == '__main__':
    init_db()
    load_permanent_tables()
    threading.Thread(target=auto_tick_loop, daemon=True).start()
    print('\n' + '=' * 72)
    print(' LAN POKER v11 — Texas Hold’em')
    print('=' * 72)
    print(f' На телефоне-хосте: http://127.0.0.1:{PORT}')
    print(f' Панель хоста:       http://127.0.0.1:{PORT}/host.html')
    ips = local_ipv4_addresses()
    if ips:
        print(' Для друзей:')
        for ip in ips:
            print(f'   http://{ip}:{PORT}')
    else:
        print(' Адрес сети не определён. Подключитесь к Wi-Fi/hotspot и перезапустите сервер.')
    print('-' * 72)
    print(' ГЛОБАЛЬНЫЙ АДМИНИСТРАТОР (новые данные при каждом запуске):')
    print(f' Логин:  {ADMIN_NICK}')
    print(f' Пароль: {ADMIN_PASSWORD}')
    print(' Войдите ими во вкладке «Аккаунт» — админ подключается как наблюдатель.')
    print('-' * 72)
    print(' Глобальный админ создаёт постоянные cash/турнирные столы из панели.')
    print(' Режим показа чужих карт по умолчанию выключен и доступен только админу.')
    print(' Создатель обычного стола получает отдельный 6-значный код ведущего.')
    print(' Этот код управляет только его столом и НЕ позволяет выдавать фишки.')
    print(' Аккаунты и балансы сохраняются локально в poker.db')
    print(' На Android держите Termux запущенным; start_android.sh включает wake-lock, если он доступен.')
    print('=' * 72 + '\n')
    ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
