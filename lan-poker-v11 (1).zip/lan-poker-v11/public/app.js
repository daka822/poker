const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

let token = localStorage.pokerToken || '';
let tableId = localStorage.pokerTableId || '';
let hostCode = localStorage.pokerHost || '';
let tableHostCodes = {};
try { tableHostCodes = JSON.parse(localStorage.pokerTableHosts || '{}') || {}; } catch (_) {}
let isHost = false;
let isAdmin = false;
let state = null;
let polling = false;
let lastHandNo = null;
let lastBoardCount = 0;
let raiseDraft = null;
const chipDrafts = new Map();
const chipPending = new Map();
let lastPot = 0;
let lastShowdownKey = '';
let soundEnabled = localStorage.pokerSound !== '0';
let uiSize = ['auto','normal','compact','mini'].includes(localStorage.pokerUiSize) ? localStorage.pokerUiSize : 'auto';
let audioCtx = null;
let lastWinnerRevealKey = '';
const ACTION_KEYS = ['fold','check','call','raise','allin'];
const ACTION_LABELS = {fold:'Пас', check:'Чек', call:'Колл', raise:'Рейз', allin:'All-in'};
let actionOrder = (() => {
  try {
    const v = JSON.parse(localStorage.pokerActionOrder || '[]');
    return Array.isArray(v) && v.length === ACTION_KEYS.length && ACTION_KEYS.every(k => v.includes(k)) ? v : [...ACTION_KEYS];
  } catch (_) { return [...ACTION_KEYS]; }
})();


function ensureAudio() {
  if (!soundEnabled) return null;
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  } catch (_) { return null; }
}

function tone(freq, duration = .07, gain = .045, type = 'sine', when = 0) {
  const ctx = ensureAudio(); if (!ctx) return;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(gain, ctx.currentTime + when);
  g.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + when + duration);
  o.connect(g); g.connect(ctx.destination); o.start(ctx.currentTime + when); o.stop(ctx.currentTime + when + duration);
}

function playSound(kind) {
  if (!soundEnabled) return;
  if (kind === 'card') { tone(520,.045,.028,'triangle'); tone(390,.055,.02,'triangle',.035); }
  else if (kind === 'chips') { tone(980,.045,.03,'square'); tone(1320,.04,.018,'square',.045); }
  else if (kind === 'action') tone(250,.06,.025,'triangle');
  else if (kind === 'win') { tone(523,.10,.035,'sine'); tone(659,.12,.03,'sine',.08); tone(784,.18,.03,'sine',.17); }
}

document.addEventListener('pointerdown', () => ensureAudio(), {once:false, passive:true});

function effectiveUiSize() {
  if (uiSize !== 'auto') return uiSize;
  const w = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1024);
  if (w <= 390) return 'mini';
  if (w <= 560) return 'compact';
  return 'normal';
}

function applyUiSize() {
  const effective = effectiveUiSize();
  document.documentElement.dataset.ui = effective;
  const sel = $('#uiSizeSelect');
  if (sel) sel.value = uiSize;
  const hint = $('#uiSizeHint');
  if (hint) {
    const names = {normal:'обычный', compact:'компактный', mini:'мини'};
    hint.textContent = uiSize === 'auto'
      ? `Сейчас выбран автоматически: ${names[effective]}. Ширина экрана ${Math.round(window.innerWidth)} px.`
      : `Принудительно включён режим: ${names[effective]}.`;
  }
  applyActionOrder();
}

let resizeUiTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeUiTimer);
  resizeUiTimer = setTimeout(() => applyUiSize(), 80);
}, {passive:true});
applyUiSize();

function applyActionOrder() {
  const items = ACTION_KEYS.map(k => document.querySelector(`[data-action-key="${k}"]`)).filter(Boolean);
  actionOrder.forEach((key, idx) => {
    const el = document.querySelector(`[data-action-key="${key}"]`);
    if (!el) return;
    el.style.order = String(idx);
    el.style.gridColumn = effectiveUiSize() === 'mini' ? (idx < 3 ? 'span 2' : 'span 3') : '';
  });
}

function saveActionOrder() {
  localStorage.pokerActionOrder = JSON.stringify(actionOrder);
  applyActionOrder();
  renderActionOrderEditor();
}

function moveAction(key, delta) {
  const i = actionOrder.indexOf(key);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= actionOrder.length) return;
  [actionOrder[i], actionOrder[j]] = [actionOrder[j], actionOrder[i]];
  saveActionOrder();
}

function renderActionOrderEditor() {
  const box = $('#actionOrderEditor');
  if (!box) return;
  box.innerHTML = actionOrder.map((key, i) => `<div class="actionOrderRow"><span><b>${i + 1}</b>${ACTION_LABELS[key]}</span><div><button type="button" class="tiny ghost orderLeft" data-key="${key}" ${i===0?'disabled':''}>←</button><button type="button" class="tiny ghost orderRight" data-key="${key}" ${i===actionOrder.length-1?'disabled':''}>→</button></div></div>`).join('');
  box.querySelectorAll('.orderLeft').forEach(b => b.onclick = () => moveAction(b.dataset.key, -1));
  box.querySelectorAll('.orderRight').forEach(b => b.onclick = () => moveAction(b.dataset.key, 1));
}

function chipTier(amount) {
  const n = Number(amount) || 0;
  if (n >= 10000) return 't5';
  if (n >= 5000) return 't4';
  if (n >= 1000) return 't3';
  if (n >= 250) return 't2';
  return 't1';
}

function chipVisual(amount, mini = false) {
  const n = Math.max(0, Math.floor(Number(amount) || 0));
  return `<span class="chipValue ${mini ? 'miniChipValue' : ''}"><span class="chipPile ${chipTier(n)}"><i></i><i></i><i></i></span><b>${n}</b></span>`;
}

function escapeHtml(v) {
  return String(v ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

function toast(text, ms = 2800) {
  const el = $('#toast');
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => el.classList.remove('show'), ms);
}

function syncModalOpen() {
  const ids = ['raiseModal','settingsModal','logsModal','statsModal','termsModal','noticeModal','adminAccountsModal'];
  const anyOpen = ids.some(id => { const el = $('#' + id); return el && !el.classList.contains('hidden'); });
  document.body.classList.toggle('modalOpen', anyOpen);
}


function clearSession(keepHost = true) {
  localStorage.removeItem('pokerToken');
  localStorage.removeItem('pokerTableId');
  token = '';
  tableId = '';
  state = null;
  isHost = false;
  isAdmin = false;
  if (!keepHost) {
    localStorage.removeItem('pokerHost');
    hostCode = '';
  }
}

async function api(path, data = {}) {
  const r = await fetch(path, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    cache: 'no-store',
    body: JSON.stringify({token, tableId, hostCode, ...data})
  });
  let j = {};
  try { j = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error(j.error || `Ошибка ${r.status}`);
  return j;
}

function card(c, delay = null, highlighted = false, extraClass = '') {
  const anim = delay === null ? '' : ' dealCard';
  const made = highlighted ? ' madeCard' : '';
  const extra = extraClass ? ` ${extraClass}` : '';
  const style = delay === null ? '' : ` style="--deal-delay:${Math.max(0, delay)}ms"`;
  if (!c) return `<div class="card back${anim}${extra}"${style}></div>`;
  const red = 'hd'.includes(c[1]) ? ' red' : '';
  const suit = {s:'♠', h:'♥', d:'♦', c:'♣'}[c[1]];
  const rank = c[0] === 'T' ? '10' : c[0];
  return `<div class="card${red}${anim}${made}${extra}"${style}><span>${rank}</span><b>${suit}</b></div>`;
}

function recordHtml(rec) {
  if (!rec) return '<small>Пока нет сохранённых шоудаунов</small>';
  const cards = (rec.bestCards || []).map(c => card(c, null, true, 'recordMiniCard')).join('');
  const d = new Date(rec.achievedAt);
  const when = Number.isFinite(d.getTime()) ? d.toLocaleString([], {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : '';
  return `<div class="recordTitle"><b>${escapeHtml(rec.handName)}</b><span>${escapeHtml(rec.nick)}</span></div><div class="recordCards">${cards}</div><small>${escapeHtml(rec.tableName)} · #${rec.handNo}${rec.potWon ? ` · выигрыш ${rec.potWon}` : ''}${when ? ` · ${when}` : ''}</small>`;
}

async function loadStats() {
  try {
    const r = await fetch('/api/stats', {cache:'no-store'});
    const j = await r.json();
    const leaders = (j.leaders || []).slice(0, 10);
    $('#leaderboard').innerHTML = leaders.length ? leaders.map((x,i) => `<div class="leaderRow"><span class="leaderPlace">${i+1}</span><b>${escapeHtml(x.nick)}</b><span class="leaderPeak">${chipVisual(x.peakBalance, true)}</span><small>сейчас ${x.balance}</small></div>`).join('') : '<small>Пока нет аккаунтов</small>';
    $('#allTimeRecord').innerHTML = recordHtml(j.allTimeHand);
    $('#todayRecord').innerHTML = recordHtml(j.todayHand);
  } catch (_) {
    if ($('#leaderboard')) $('#leaderboard').innerHTML = '<small>Статистика недоступна</small>';
  }
}

async function loadTables(selectId = tableId) {
  try {
    const r = await fetch('/api/tables', {cache: 'no-store'});
    const j = await r.json();
    const list = $('#tableList');
    list.innerHTML = '';
    if (!j.tables?.length) {
      list.innerHTML = '<div class="muted">Пока нет столов</div>';
      return;
    }
    j.tables.forEach((t, index) => {
      const item = document.createElement('button');
      item.className = 'tablePick';
      item.dataset.tableId = t.id;
      item.dataset.passworded = t.passworded ? '1' : '0';
      const lock = t.passworded ? ' 🔒' : '';
      const permanent = t.permanent ? ' <em class="tableBadge">∞</em>' : '';
      const mode = t.mode === 'tournament' ? ` <em class="tableBadge tour">T${t.tournamentLevel || 1}</em>` : '';
      item.innerHTML = `<span><b>${escapeHtml(t.name)}${lock}${permanent}${mode}</b><small>${t.players}/${t.maxPlayers} игроков · ${t.blinds} · ${t.mode === 'tournament' ? 'турнир' : 'cash'} · ${escapeHtml(t.phase)}</small></span><strong>${t.paused ? '⏸' : '▶'}</strong>`;
      item.onclick = () => selectTable(t.id);
      list.appendChild(item);
      if ((selectId && t.id === selectId) || (!selectId && index === 0)) selectTable(t.id);
    });
    if (!j.tables.some(t => t.id === $('#selectedTable').value)) selectTable(j.tables[0].id);
  } catch (e) {
    $('#tableList').innerHTML = '<div class="muted">Не удалось получить список столов</div>';
  }
}

function selectTable(id) {
  $('#selectedTable').value = id;
  $$('.tablePick').forEach(el => el.classList.toggle('selected', el.dataset.tableId === id));
  const item = $(`.tablePick[data-table-id="${id}"]`);
  const locked = item?.dataset.passworded === '1';
  $('#tablePasswordWrap').classList.toggle('hidden', !locked);
}

async function join(mode) {
  try {
    const selected = $('#selectedTable').value;
    if (!selected) throw new Error('Выберите стол');
    let nick, password = '';
    if (mode === 'guest') nick = $('#guestNick').value;
    else {
      nick = $('#accountNick').value;
      password = $('#accountPassword').value;
    }
    const tablePassword = $('#tablePassword').value;
    const acceptTerms = mode === 'register' ? !!$('#acceptTerms')?.checked : false;
    const acceptPrivacy = mode === 'register' ? !!$('#acceptPrivacy')?.checked : false;
    if (mode === 'register' && !acceptTerms) throw new Error('Для регистрации примите Пользовательское соглашение');
    if (mode === 'register' && !acceptPrivacy) throw new Error('Для регистрации отдельно подтвердите согласие на обработку данных аккаунта');
    const j = await api('/api/join', {tableId: selected, nick, password, mode, tablePassword, acceptTerms, acceptPrivacy});
    token = j.token;
    tableId = j.tableId;
    hostCode = tableHostCodes[tableId] || '';
    isAdmin = !!j.admin;
    localStorage.pokerToken = token;
    localStorage.pokerTableId = tableId;
    localStorage.pokerHost = hostCode;
    showApp();
    toast(j.admin ? 'Глобальный администратор подключён как наблюдатель' : (j.account ? `Аккаунт загружен · баланс ${j.chips}` : 'Вы сели за стол как гость'));
  } catch (e) { toast(e.message); }
}

function applyHostUI() {
  $('#hostPanel').classList.toggle('hidden', !isHost);
  $('#adminAccountsBtn').classList.toggle('hidden', !isAdmin);
  $('#hostAccess').textContent = isAdmin ? 'Админ' : (isHost ? 'Вы ведущий' : 'Ведущий');
  $('#hostAccess').classList.toggle('active', isHost);
  if (isHost) $('#hostLogin').classList.add('hidden');
}

function showApp() {
  $('#join').classList.add('hidden');
  $('#app').classList.remove('hidden');
  applyHostUI();
  if (!polling) poll();
}

function showJoin() {
  $('#app').classList.add('hidden');
  $('#join').classList.remove('hidden');
  polling = false;
  loadTables();
}

function positions(n, youIndex) {
  const arr = Array(n);
  const origin = Number.isInteger(youIndex) ? youIndex : 0;
  const mobile = ['compact','mini'].includes(effectiveUiSize());
  const mobileProfiles = {
    1: [[50,86]],
    2: [[50,86],[50,15]],
    3: [[50,86],[17,20],[83,20]],
    4: [[50,86],[12,36],[50,14],[88,36]],
    5: [[50,86],[11,59],[18,20],[82,20],[89,59]],
    6: [[50,87],[12,66],[12,30],[50,13],[88,30],[88,66]],
    7: [[50,88],[14,69],[9,42],[26,16],[74,16],[91,42],[86,69]],
    8: [[50,88],[19,76],[8,51],[16,22],[50,12],[84,22],[92,51],[81,76]],
    9: [[50,88],[22,78],[8,58],[10,31],[31,13],[69,13],[90,31],[92,58],[78,78]]
  };
  if (mobile && mobileProfiles[n]) {
    for (let i = 0; i < n; i++) {
      const rel = (i - origin + n) % n;
      arr[i] = mobileProfiles[n][rel];
    }
    return arr;
  }
  for (let i = 0; i < n; i++) {
    const rel = (i - origin + n) % n;
    const angle = (90 + 360 * rel / Math.max(1, n)) * Math.PI / 180;
    arr[i] = [50 + 43 * Math.cos(angle), 50 + 39 * Math.sin(angle)];
  }
  return arr;
}

async function becomeHost() {
  try {
    const code = $('#hostAccessCode').value.trim();
    if (!/^\d{6}$/.test(code)) throw new Error('Введите 6-значный код ведущего');
    const j = await api('/api/host', {hostCode: code});
    if (!j.isHost) throw new Error('Сервер не подтвердил права ведущего');
    hostCode = code;
    isHost = true;
    localStorage.pokerHost = hostCode;
    tableHostCodes[tableId] = hostCode;
    localStorage.pokerTableHosts = JSON.stringify(tableHostCodes);
    applyHostUI();
    toast('Режим ведущего включён');
  } catch (e) { toast(e.message); }
}

async function leaveTable() {
  try { if (token && tableId) await api('/api/leave'); } catch (_) {}
  clearSession(true);
  showJoin();
  toast('Вы вышли со стола');
}

function isBettingPhase(s) {
  return ['preflop','flop','turn','river'].includes(s.phase);
}

function raiseBounds(s = state) {
  if (!s || s.youIndex == null || !s.players[s.youIndex]) return null;
  const you = s.players[s.youIndex];
  const min = s.currentBet + s.minRaise;
  const max = s.maxRaiseTarget || (you.roundBet + you.chips);
  return {you, min, max, current: s.currentBet, pot: s.pot, toCall: s.toCall || 0};
}

function clampRaise(value, bounds) {
  let v = Number.isFinite(+value) ? Math.round(+value) : bounds.min;
  return Math.max(bounds.min, Math.min(bounds.max, v));
}

function updateRaiseUI(value = raiseDraft) {
  const b = raiseBounds();
  if (!b) return;
  raiseDraft = clampRaise(value, b);
  $('#raiseAmount').min = b.min;
  $('#raiseAmount').max = b.max;
  $('#raiseAmount').value = raiseDraft;
  $('#raiseSlider').min = b.min;
  $('#raiseSlider').max = Math.max(b.min, b.max);
  $('#raiseSlider').value = raiseDraft;
  $('#raiseCurrent').textContent = b.current;
  $('#raiseMinimum').textContent = b.min;
  $('#raisePot').textContent = b.pot;
  $('#raiseStack').textContent = b.you.chips;
  $('#raiseRangeMin').textContent = b.min;
  $('#raiseRangeMax').textContent = b.max;
  const add = Math.max(0, raiseDraft - b.you.roundBet);
  $('#raiseExplain').textContent = `Добавить из стека: ${add}${b.toCall ? ` · колл внутри суммы: ${b.toCall}` : ''}`;
  $('#confirmRaise').textContent = raiseDraft >= b.max ? `All-in до ${raiseDraft}` : `Рейз до ${raiseDraft}`;
  $('#threeBetPreset').textContent = state.currentBet > state.bigBlind ? `3-bet · ×3 (${state.currentBet * 3})` : `3× BB (${state.bigBlind * 3})`;
}

function openRaise() {
  const b = raiseBounds();
  if (!b || !state || state.youIndex !== state.turn || !state.can.raise) return toast('Сейчас рейз недоступен');
  raiseDraft = b.min;
  updateRaiseUI(raiseDraft);
  $('#raiseModal').classList.remove('hidden');
  syncModalOpen();
}

function closeRaise() {
  $('#raiseModal').classList.add('hidden');
  syncModalOpen();
}

function presetRaise(kind) {
  const b = raiseBounds();
  if (!b) return;
  const potAfterCall = b.pot + b.toCall;
  let target = b.min;
  if (kind === '2min') target = b.min * 2;
  else if (kind === '3min') target = b.min * 3;
  else if (kind === 'halfpot') target = b.current + Math.round(potAfterCall * .5);
  else if (kind === 'pot') target = b.current + potAfterCall;
  else if (kind === '3bet') target = state.currentBet > state.bigBlind ? state.currentBet * 3 : state.bigBlind * 3;
  updateRaiseUI(target);
}

function renderChipAdmin(s) {
  const container = $('#chipAdmin');
  const liveIds = new Set(s.players.map(p => p.id));
  [...container.querySelectorAll('.chipRow')].forEach(row => { if (!liveIds.has(row.dataset.playerId)) row.remove(); });
  const editable = !isBettingPhase(s) && s.canGiveChips;

  s.players.forEach(p => {
    let row = container.querySelector(`.chipRow[data-player-id="${p.id}"]`);
    if (!row) {
      row = document.createElement('div');
      row.className = 'chipRow';
      row.dataset.playerId = p.id;
      row.innerHTML = `<span class="chipPlayer"></span><input class="chipInput" type="number" min="0" inputmode="numeric"><button class="saveChip">Установить</button><button class="kick danger">Выгнать</button>`;
      const input = row.querySelector('input');
      const save = row.querySelector('.saveChip');
      const kick = row.querySelector('.kick');
      input.addEventListener('input', () => chipDrafts.set(p.id, input.value));
      input.addEventListener('keydown', e => { if (e.key === 'Enter') save.click(); });
      save.onclick = async () => {
        const amount = Math.max(0, Math.floor(Number(input.value)));
        if (!Number.isFinite(amount)) return toast('Введите количество фишек');
        chipPending.set(p.id, amount);
        chipDrafts.delete(p.id);
        try {
          await api('/api/chips', {playerId: p.id, amount});
          toast(`${p.nick}: ${amount} фишек`);
        } catch (e) { chipPending.delete(p.id); toast(e.message); }
      };
      kick.onclick = async () => {
        if (!confirm(`Выгнать игрока ${p.nick}?`)) return;
        try { await api('/api/kick', {playerId: p.id}); toast(`${p.nick} выгнан`); }
        catch (e) { toast(e.message); }
      };
      container.appendChild(row);
    }
    const input = row.querySelector('input');
    const save = row.querySelector('.saveChip');
    row.querySelector('.chipPlayer').innerHTML = `${escapeHtml(p.nick)} ${p.account ? '<small>акк</small>' : '<small>гость</small>'}`;
    row.classList.toggle('noChipEdit', !s.canGiveChips);
    input.classList.toggle('hidden', !s.canGiveChips);
    save.classList.toggle('hidden', !s.canGiveChips);
    input.disabled = !editable;
    save.disabled = !editable;
    if (s.canGiveChips) {
      if (chipPending.has(p.id)) {
        input.value = chipPending.get(p.id);
        if (p.chips === chipPending.get(p.id)) chipPending.delete(p.id);
      } else if (chipDrafts.has(p.id)) input.value = chipDrafts.get(p.id);
      else if (document.activeElement !== input) input.value = p.chips;
    }
  });
}

function render(s) {
  const previousHand = lastHandNo;
  const previousBoardCount = lastBoardCount;
  const newHand = previousHand !== null && s.handNo !== previousHand;
  const firstActiveRender = previousHand === null && s.handNo > 0 && isBettingPhase(s);
  const animateDeal = newHand || firstActiveRender;
  const boardGrew = s.handNo === previousHand && s.board.length > previousBoardCount;

  state = s;
  isHost = !!s.isHost;
  isAdmin = !!s.isAdmin;
  applyHostUI();
  $('#tableName').textContent = s.tableName;
  const modeInfo = s.mode === 'tournament' ? `Турнир · L${s.tournamentLevel}` : (s.permanent ? 'Постоянный стол' : '');
  const phaseLabels = {lobby:'Ожидание', preflop:'Префлоп', flop:'Флоп', turn:'Тёрн', river:'Ривер', showdown:'Шоудаун'};
  const phaseText = phaseLabels[s.phase] || s.phase || '';
  $('#phase').textContent = [phaseText, modeInfo].filter(Boolean).join(' · ');
  $('#pot').innerHTML = chipVisual(s.pot, true);
  $('#message').textContent = s.message || '';
  $('#showCardsBtn').classList.toggle('hidden', !s.canShowCards);

  const boardHighlights = new Set(s.boardHighlights || []);
  const showdownActive = !!(s.showdown && s.phase === 'showdown');
  $('#board').innerHTML = s.board.map((c, i) => card(c, boardGrew && i >= previousBoardCount ? (i - previousBoardCount) * 140 : null, boardHighlights.has(c), showdownActive && boardHighlights.has(c) ? 'winnerBoardCard' : '')).join('');
  const potCenter = $('#potCenter');
  if (s.pot > 0 && isBettingPhase(s)) {
    potCenter.classList.remove('hidden');
    potCenter.innerHTML = `<span>Банк</span>${chipVisual(s.pot, false)}`;
  } else potCenter.classList.add('hidden');

  const winningHands = s.showdown?.winningHands || [];
  const revealKey = winningHands.length ? `${s.handNo}:${winningHands.map(w => `${w.playerId}:${w.award}:${(w.cards||[]).join('-')}`).join('|')}` : '';
  const winnerReveal = $('#winnerReveal');
  if (revealKey) {
    if (revealKey !== lastWinnerRevealKey) {
      winnerReveal.innerHTML = winningHands.map((w, wi) => `<div class="winnerRevealRow"><div class="winnerRevealTitle"><b>🏆 ${escapeHtml(w.nick)}</b><span>${escapeHtml(w.handName)} · +${w.award}</span></div><div class="winnerComboCards">${(w.cards || []).map((c, ci) => card(c, wi * 80 + ci * 90, true, 'winnerComboCard')).join('')}</div></div>`).join('');
      lastWinnerRevealKey = revealKey;
    }
    winnerReveal.classList.remove('hidden');
  } else {
    winnerReveal.classList.add('hidden');
    winnerReveal.innerHTML = '';
    lastWinnerRevealKey = '';
  }

  if (animateDeal) setTimeout(() => playSound('card'), 80);
  if (boardGrew) setTimeout(() => playSound('card'), 80);
  if (previousHand !== null && s.pot > lastPot) playSound('chips');
  const showdownKey = s.showdown ? `${s.handNo}:${s.showdown.text}` : '';
  if (showdownKey && showdownKey !== lastShowdownKey) playSound('win');
  lastPot = s.pot;
  lastShowdownKey = showdownKey;

  const pos = positions(s.players.length, s.youIndex);
  $('#players').innerHTML = s.players.map((p, i) => {
    let cards = '';
    const relDelay = ((i - (s.youIndex ?? 0) + s.players.length) % Math.max(1, s.players.length)) * 70;
    const winnerHand = winningHands.find(w => w.playerId === p.id);
    const winnerMade = new Set(winnerHand?.cards || []);
    const made = winnerMade.size ? winnerMade : new Set(p.highlightCards || []);
    if (p.cards.length) cards = p.cards.map((c, ci) => card(c, animateDeal ? relDelay + ci * 110 : null, made.has(c), winnerMade.has(c) ? 'winnerHoleCard' : '')).join('');
    else if (p.inHand && isBettingPhase(s) && !p.folded) cards = card(null, animateDeal ? relDelay : null) + card(null, animateDeal ? relDelay + 110 : null);
    const status = p.waiting ? '<div class="waitTag">ЖДЁТ СЛЕДУЮЩУЮ</div>' : (p.allIn ? '<div class="bet allInTag">ALL-IN</div>' : '');
    const odds = s.isAdmin && s.adminRevealCards && s.adminOdds && s.adminOdds[p.id] != null ? `<div class="equityTag" title="Шанс на лучшую руку с учётом дележа банка">${Number(s.adminOdds[p.id]).toFixed(1)}% на победу</div>` : '';
    const combo = p.handName && p.handRank > 0 ? `<div class="comboTag comboRank${p.handRank}">${escapeHtml(p.handName)}</div>` : '';
    return `<div class="player ${i === s.turn ? 'turn' : ''} ${p.folded && p.inHand ? 'folded' : ''} ${p.isYou ? 'you' : ''} ${p.waiting ? 'waiting' : ''} ${p.handRank > 0 ? `combo comboRank${p.handRank}` : ''}" style="left:${pos[i][0]}%;top:${pos[i][1]}%">
      <div class="miniCards">${cards}</div>
      <div class="box">
        <div class="name">${escapeHtml(p.nick)}${i === s.dealer ? '<span class="dealer">D</span>' : ''}${p.isYou ? '<span class="youTag">ВЫ</span>' : ''}${p.account ? '<span class="accountTag">★</span>' : ''}</div>
        <div class="chips">${chipVisual(p.chips, true)}</div>
        ${p.roundBet ? `<div class="bet"><span>ставка</span>${chipVisual(p.roundBet, true)}</div>` : ''}${odds}${combo}${status}
      </div>
    </div>`;
  }).join('');

  if (s.isAdmin && s.adminRevealCards && isBettingPhase(s)) {
    $('#adminOddsHint').classList.remove('hidden');
  } else $('#adminOddsHint').classList.add('hidden');

  const yourTurn = s.youIndex === s.turn && isBettingPhase(s);
  const you = s.youIndex != null ? s.players[s.youIndex] : null;
  if (s.isAdmin && s.youIndex == null) $('#turnInfo').textContent = 'Режим администратора · вы наблюдаете и управляете столом.';
  else if (you?.waiting) $('#turnInfo').textContent = 'Вы наблюдаете. Карты будут со следующей раздачи.';
  else $('#turnInfo').textContent = yourTurn ? (s.toCall ? `Ваш ход · колл ${s.toCall}` : 'Ваш ход · можно чек') : (s.message || '');

  const preBtn = $('#preActionBtn');
  const canPre = !!(you && isBettingPhase(s) && you.inHand && !you.folded && !you.allIn && !yourTurn && !you.waiting && !s.isAdmin);
  preBtn.disabled = !canPre;
  preBtn.classList.toggle('armed', s.preAction === 'checkfold');
  preBtn.textContent = s.preAction === 'checkfold' ? '☑ Авто Чек / Фолд · ВКЛ' : '☐ Авто Чек / Фолд';

  $$('[data-act]').forEach(b => b.disabled = !yourTurn || !s.can[b.dataset.act]);
  $('#callBtn').textContent = s.toCall ? `Колл ${s.toCall}` : 'Колл';
  const allinBtn = $('[data-act="allin"]');
  if (allinBtn) allinBtn.textContent = yourTurn && s.maxRaiseTarget ? `All-in до ${s.maxRaiseTarget}` : 'All-in';
  $('#raiseBtn').disabled = !yourTurn || !s.can.raise;
  if (!yourTurn && !$('#raiseModal').classList.contains('hidden')) closeRaise();
  else if (yourTurn && !$('#raiseModal').classList.contains('hidden')) updateRaiseUI(raiseDraft);

  if (isHost) {
    const editable = !isBettingPhase(s);
    if (document.activeElement !== $('#sb') && $('#sb').dataset.dirty !== '1') $('#sb').value = s.smallBlind;
    if (document.activeElement !== $('#bb') && $('#bb').dataset.dirty !== '1') $('#bb').value = s.bigBlind;
    $('#saveSettings').disabled = !editable;
    $('#sb').disabled = !editable;
    $('#bb').disabled = !editable;
    $('#startHand').disabled = isBettingPhase(s) || s.players.filter(p => p.chips > 0).length < 2;
    $('#toggleAuto').textContent = s.hostPaused ? 'Автоигра: ВЫКЛ · включить' : 'Автоигра: ВКЛ · остановить';
    $('#toggleAuto').classList.toggle('danger', s.hostPaused);
    $('#autoHint').textContent = s.hostPaused ? 'После текущей раздачи новая сама не начнётся.' : 'При 2+ игроках следующая раздача стартует автоматически.';
    $('#hostStatus').textContent = `${s.isAdmin ? 'АДМИН · ' : ''}${s.players.length}/${s.maxPlayers} игроков · ${isBettingPhase(s) ? 'идёт раздача' : (s.hostPaused ? 'автостарт остановлен' : 'автостарт включён')}`;
    $('#chipHelp').textContent = s.canGiveChips ? 'Администратор может менять баланс между раздачами · «Выгнать» работает всегда' : 'Ведущий стола может выгонять игроков, но не может выдавать фишки';
    $('#deleteTable').classList.toggle('hidden', !s.canDeleteTable);
    $('#revealCards').classList.toggle('hidden', !s.canRevealCards);
    $('#revealCards').textContent = s.adminRevealCards ? '👁 Показ карт: ВКЛ · выключить' : '👁 Показ карт: ВЫКЛ · включить';
    $('#revealCards').classList.toggle('active', !!s.adminRevealCards);
    $('#adminTableTools').classList.toggle('hidden', !s.canCreatePermanentTables);
    if (s.mode === 'tournament') {
      $('#chipHelp').textContent = `Турнир · стартовый стек ${s.tournamentStack} · уровень ${s.tournamentLevel}, рост каждые ${s.levelHands} раздач`;
    }
    renderChipAdmin(s);
  }

  updateTimers();
  lastHandNo = s.handNo;
  lastBoardCount = s.board.length;
}

function updateTimers() {
  if (!state) return;
  const now = Date.now();
  if (state.turnExpiresAt && isBettingPhase(state)) {
    const left = Math.max(0, Math.ceil((state.turnExpiresAt - now) / 1000));
    $('#turnTimer').classList.remove('hidden');
    $('#turnTimer strong').textContent = left;
    $('#turnTimer').classList.toggle('urgent', left <= 5);
  } else $('#turnTimer').classList.add('hidden');

  if (state.nextHandAt && !isBettingPhase(state)) {
    const left = Math.max(0, Math.ceil((state.nextHandAt - now) / 1000));
    $('#autoStartInfo').textContent = state.hostPaused ? '' : `Следующая раздача через ${left}…`;
  } else $('#autoStartInfo').textContent = '';
}
setInterval(updateTimers, 200);

async function poll() {
  polling = true;
  while (token && tableId) {
    try {
      const q = new URLSearchParams({token, tableId, hostCode});
      const r = await fetch('/api/state?' + q.toString(), {cache: 'no-store'});
      const j = await r.json();
      if (r.status === 401 || r.status === 404) {
        clearSession(true);
        showJoin();
        toast(r.status === 401 ? 'Вы вышли или были удалены со стола' : 'Стол больше не существует');
        break;
      }
      if (!r.ok) throw new Error(j.error || `Ошибка ${r.status}`);
      render(j);
    } catch (_) {
      $('#turnInfo').textContent = 'Нет связи с локальным сервером…';
    }
    await new Promise(r => setTimeout(r, 400));
  }
  polling = false;
}

async function createTable(opts) {
  const r = await fetch('/api/table/create', {
    method: 'POST', headers: {'Content-Type':'application/json'}, cache:'no-store',
    body: JSON.stringify(opts)
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || 'Не удалось создать стол');
  tableHostCodes[j.table.id] = j.hostCode;
  localStorage.pokerTableHosts = JSON.stringify(tableHostCodes);
  await loadTables(j.table.id);
  $('#createdHostCode').textContent = j.hostCode;
  $('#createdTableInfo').classList.remove('hidden');
  toast(`Создан «${j.table.name}». Код ведущего: ${j.hostCode}`, 5000);
  return j.table;
}

async function claimRelief() {
  try {
    const nick = $('#accountNick').value.trim();
    const password = $('#accountPassword').value;
    const r = await fetch('/api/account/relief', {
      method:'POST', headers:{'Content-Type':'application/json'}, cache:'no-store',
      body:JSON.stringify({nick, password})
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Не удалось получить бонус');
    toast(`Начислено ${j.balance} фишек. Следующий банкротный бонус — через 6 минут.`, 4500);
  } catch (e) { toast(e.message, 4200); }
}

// Rating / legal modals
function openStats() { $('#statsModal').classList.remove('hidden'); syncModalOpen(); loadStats(); }
function closeStats() { $('#statsModal').classList.add('hidden'); syncModalOpen(); }
function openTerms() { $('#termsModal').classList.remove('hidden'); syncModalOpen(); }
function closeTerms() { $('#termsModal').classList.add('hidden'); syncModalOpen(); }
function openNotice() { $('#noticeModal').classList.remove('hidden'); syncModalOpen(); }
function closeNotice() { $('#noticeModal').classList.add('hidden'); syncModalOpen(); }

$('#statsBtn').onclick = openStats;
$('#closeStats').onclick = closeStats;
$('[data-close-stats]').onclick = closeStats;
$('#closeTerms').onclick = closeTerms;
$('[data-close-terms]').onclick = closeTerms;
$('#openTermsFromRegister').onclick = openTerms;
$('#openTermsFromMenu').onclick = openTerms;
$('#openTermsFromNotice').onclick = openTerms;
$('#acceptNotice').onclick = () => { sessionStorage.pokerNoticeAccepted = '1'; closeNotice(); };
if (sessionStorage.pokerNoticeAccepted !== '1') openNotice();

// Join screen
$('#guestTab').onclick = () => { $('#guestTab').classList.add('active'); $('#accountTab').classList.remove('active'); $('#guestJoin').classList.remove('hidden'); $('#accountJoin').classList.add('hidden'); };
$('#accountTab').onclick = () => { $('#accountTab').classList.add('active'); $('#guestTab').classList.remove('active'); $('#accountJoin').classList.remove('hidden'); $('#guestJoin').classList.add('hidden'); };
$('#guestJoinBtn').onclick = () => join('guest');
$('#loginBtn').onclick = () => join('login');
$('#registerBtn').onclick = () => join('register');
$('#refreshTables').onclick = () => loadTables($('#selectedTable').value);
$('#refreshStats').onclick = loadStats;
$('#createTableBtn').onclick = async () => {
  try {
    const t = await createTable({
      name: $('#newTableName').value,
      smallBlind: Number($('#newTableSB').value),
      bigBlind: Number($('#newTableBB').value),
      maxPlayers: Number($('#newTableMax').value),
      tablePassword: $('#newTablePassword').value,
      mode: $('#newTableMode').value,
      tournamentStack: Number($('#newTournamentStack').value),
      levelHands: Number($('#newLevelHands').value)
    });
    $('#selectedTable').value = t.id;
  } catch (e) { toast(e.message); }
};
$('#reliefBtn').onclick = claimRelief;
function syncTournamentOptions(modeEl, optionsEl) {
  const update = () => $(optionsEl).classList.toggle('hidden', $(modeEl).value !== 'tournament');
  $(modeEl).addEventListener('change', update); update();
}
syncTournamentOptions('#newTableMode', '#newTournamentOptions');
syncTournamentOptions('#adminTableMode', '#adminTournamentOptions');

// Main UI
$('#preActionBtn').onclick = async () => {
  if (!state) return;
  try {
    const next = state.preAction === 'checkfold' ? null : 'checkfold';
    const j = await api('/api/preaction', {preAction: next});
    state.preAction = j.preAction || null;
    $('#preActionBtn').classList.toggle('armed', !!state.preAction);
    toast(state.preAction ? 'Авто Чек/Фолд включён до вашего хода' : 'Авто Чек/Фолд выключен');
  } catch (e) { toast(e.message); }
};

$('#hostAccess').onclick = () => {
  if (isHost) return toast('Режим ведущего уже включён');
  $('#hostLogin').classList.toggle('hidden');
  if (!$('#hostLogin').classList.contains('hidden')) {
    $('#hostAccessCode').value = tableHostCodes[tableId] || hostCode || '';
    $('#hostAccessCode').focus();
  }
};
$('#hostAccessConfirm').onclick = becomeHost;
$('#hostAccessCode').addEventListener('keydown', e => { if (e.key === 'Enter') becomeHost(); });
$('#leaveBtn').onclick = leaveTable;

$$('[data-act]').forEach(b => b.onclick = async () => {
  try { await api('/api/action', {action: b.dataset.act}); playSound(b.dataset.act === 'call' || b.dataset.act === 'allin' ? 'chips' : 'action'); }
  catch (e) { toast(e.message); }
});
$('#raiseBtn').onclick = openRaise;
$('#closeRaise').onclick = closeRaise;
$('[data-close-raise]').onclick = closeRaise;
$$('[data-raise-preset]').forEach(b => b.onclick = () => presetRaise(b.dataset.raisePreset));
$('#raiseSlider').oninput = e => updateRaiseUI(e.target.value);
$('#raiseAmount').oninput = e => { raiseDraft = Number(e.target.value); $('#raiseSlider').value = raiseDraft; };
$('#raiseAmount').onchange = e => updateRaiseUI(e.target.value);
$('#confirmRaise').onclick = async () => {
  try { const amount = Number($('#raiseAmount').value); await api('/api/action', {action:'raise', amount}); playSound('chips'); closeRaise(); }
  catch (e) { toast(e.message); }
};

['sb','bb'].forEach(id => {
  $('#' + id).addEventListener('input', e => e.target.dataset.dirty = '1');
  $('#' + id).addEventListener('blur', e => { if (!e.target.value) e.target.dataset.dirty = ''; });
});
$('#saveSettings').onclick = async () => {
  try {
    await api('/api/settings', {smallBlind:Number($('#sb').value), bigBlind:Number($('#bb').value)});
    $('#sb').dataset.dirty = ''; $('#bb').dataset.dirty = '';
    toast('Блайнды сохранены');
  } catch (e) { toast(e.message); }
};
$('#startHand').onclick = async () => { try { await api('/api/start'); } catch (e) { toast(e.message); } };
$('#toggleAuto').onclick = async () => {
  try { await api('/api/autoplay', {paused: !state.hostPaused}); }
  catch (e) { toast(e.message); }
};
$('#deleteTable').onclick = async () => {
  if (!state?.isAdmin) return toast('Удалять столы может только глобальный администратор');
  if (!confirm(`Удалить стол «${state.tableName}»? Все игроки вернутся в главное меню.`)) return;
  try { await api('/api/table/delete'); clearSession(true); showJoin(); toast('Стол удалён'); }
  catch (e) { toast(e.message); }
};
$('#revealCards').onclick = async () => {
  if (!state?.isAdmin) return toast('Показ чужих карт доступен только главному администратору');
  try {
    const enabled = !state.adminRevealCards;
    await api('/api/admin/reveal', {enabled});
    toast(enabled ? 'Показ скрытых карт включён только для вашего админ-экрана' : 'Показ скрытых карт выключен');
  } catch (e) { toast(e.message); }
};

$('#adminCreateTable').onclick = async () => {
  if (!state?.isAdmin) return toast('Только главный администратор');
  try {
    const j = await api('/api/admin/table/create', {
      name: $('#adminTableName').value,
      smallBlind: Number($('#adminTableSB').value),
      bigBlind: Number($('#adminTableBB').value),
      maxPlayers: Number($('#adminTableMax').value),
      tablePassword: $('#adminTablePassword').value,
      mode: $('#adminTableMode').value,
      tournamentStack: Number($('#adminTournamentStack').value),
      levelHands: Number($('#adminLevelHands').value),
      permanent: $('#adminPermanent').checked
    });
    tableHostCodes[j.table.id] = j.hostCode;
    localStorage.pokerTableHosts = JSON.stringify(tableHostCodes);
    $('#adminCreatedInfo').textContent = `${j.table.permanent ? 'Постоянный' : 'Временный'} стол «${j.table.name}» создан · код ведущего ${j.hostCode}`;
    toast(`Стол «${j.table.name}» создан`, 4200);
  } catch (e) { toast(e.message, 4200); }
};

$('#hostCreateTable').onclick = async () => {
  await leaveTable();
  const d = $('.createTableBox');
  if (d) d.open = true;
};

async function loadLogs() {
  if (!token || !tableId || $('#logsModal').classList.contains('hidden')) return;
  try {
    const q = new URLSearchParams({token, tableId});
    const r = await fetch('/api/logs?' + q.toString(), {cache:'no-store'});
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Логи недоступны');
    const list = $('#logsList');
    if (!j.logs?.length) { list.innerHTML = '<div class="muted">Пока событий нет</div>'; return; }
    list.innerHTML = j.logs.slice().reverse().map(x => {
      const d = new Date(x.createdAt);
      const time = d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'});
      return `<div class="logRow log-${escapeHtml(x.type)}"><span>${time}</span><div><b>#${x.handNo || 0}</b> ${escapeHtml(x.message)}</div></div>`;
    }).join('');
  } catch (e) { $('#logsList').innerHTML = `<div class="muted">${escapeHtml(e.message)}</div>`; }
}

function openLogs() {
  $('#logsModal').classList.remove('hidden');
  syncModalOpen();
  loadLogs();
}
function closeLogs() {
  $('#logsModal').classList.add('hidden');
  syncModalOpen();
}
$('#logsBtn').onclick = openLogs;
$('#closeLogs').onclick = closeLogs;
$('[data-close-logs]').onclick = closeLogs;
$('#refreshLogs').onclick = loadLogs;
setInterval(() => { if (!$('#logsModal').classList.contains('hidden')) loadLogs(); }, 1400);

function openSettings() {
  $('#soundToggle').checked = soundEnabled;
  applyUiSize();
  renderActionOrderEditor();
  $('#settingsModal').classList.remove('hidden');
  syncModalOpen();
}
function closeSettings() {
  $('#settingsModal').classList.add('hidden');
  syncModalOpen();
}
$('#settingsBtn').onclick = openSettings;
$('#closeSettings').onclick = closeSettings;
$('[data-close-settings]').onclick = closeSettings;
$('#soundToggle').onchange = e => {
  soundEnabled = !!e.target.checked;
  localStorage.pokerSound = soundEnabled ? '1' : '0';
  if (soundEnabled) { ensureAudio(); playSound('chips'); }
  toast(soundEnabled ? 'Звуки включены' : 'Звуки выключены');
};
$('#resetActionOrder').onclick = () => {
  actionOrder = [...ACTION_KEYS];
  saveActionOrder();
  toast('Порядок кнопок сброшен');
};

$('#uiSizeSelect').onchange = e => {
  uiSize = ['auto','normal','compact','mini'].includes(e.target.value) ? e.target.value : 'auto';
  localStorage.pokerUiSize = uiSize;
  applyUiSize();
  toast(uiSize === 'auto' ? 'Размер интерфейса: авто' : `Размер интерфейса: ${uiSize === 'mini' ? 'мини' : (uiSize === 'compact' ? 'компактный' : 'обычный')}`);
};

document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeRaise(); closeSettings(); closeLogs(); closeStats(); closeTerms(); } });

applyActionOrder();
renderActionOrderEditor();

// Restore session or show table lobby.
(async function init() {
  await loadTables(tableId);
  if (token && tableId) showApp();
})();

// v11 — private admin management and voluntary card reveal
$('#showCardsBtn').onclick = async () => {
  try { await api('/api/show-cards'); $('#showCardsBtn').classList.add('hidden'); }
  catch (e) { toast(e.message); }
};
let adminAccountsData = null;
function renderAdminAccounts() {
  if (!adminAccountsData) return;
  const query = $('#adminAccountSearch').value.trim().toLocaleLowerCase();
  const accounts = adminAccountsData.accounts.filter(a => a.nick.toLocaleLowerCase().includes(query));
  const guests = adminAccountsData.guests.filter(a => a.nick.toLocaleLowerCase().includes(query));
  $('#adminAccountList').innerHTML = accounts.length ? accounts.map(a => `
    <div class="adminAccountRow" data-account-id="${a.id}">
      <div class="adminAccountName"><b>${escapeHtml(a.nick)}</b><span>${a.playing ? `За столом: ${escapeHtml(a.table)}` : 'Офлайн'}</span></div>
      <div class="adminAccountInputs">
        <label>Баланс<input class="adminBalanceInput" type="number" min="0" max="1000000000" value="${a.pendingBalance ?? a.balance}" inputmode="numeric"></label>
        <button class="tiny primary" data-admin-action="balance">Сохранить фишки</button>
        <label>Новый пароль<input class="adminPasswordInput" type="password" minlength="4" maxlength="128" placeholder="4–128 символов" autocomplete="new-password"></label>
        <button class="tiny" data-admin-action="password">Сменить пароль</button>
      </div>
      ${a.pendingBalance != null ? '<small>Новый баланс применится после раздачи</small>' : ''}
    </div>`).join('') : '<p class="muted">Нет аккаунтов</p>';
  $('#adminGuestList').innerHTML = guests.length ? guests.map(g => `
    <div class="adminAccountRow" data-guest-id="${escapeHtml(g.playerId)}" data-guest-table="${escapeHtml(g.tableId)}">
      <div class="adminAccountName"><b>${escapeHtml(g.nick)}</b><span>Гость · ${escapeHtml(g.table)}</span></div>
      <div class="adminAccountInputs">
        <label>Фишки<input class="adminBalanceInput" type="number" min="0" max="1000000000" value="${g.pendingBalance ?? g.chips}" inputmode="numeric"></label>
        <button class="tiny primary" data-admin-action="guest-balance">Сохранить фишки</button>
      </div>
    </div>`).join('') : '<p class="muted">Гостей нет</p>';
}
async function loadAdminAccounts() {
  if (!state?.isAdmin) return;
  try {
    const url = '/api/admin/accounts?' + new URLSearchParams({token,tableId});
    const response = await fetch(url, {cache:'no-store'});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Не удалось получить аккаунты');
    adminAccountsData = result;
    renderAdminAccounts();
  } catch(e) { $('#adminAccountList').textContent = e.message; toast(e.message); }
}
function closeAdminAccounts() {
  $('#adminAccountsModal').classList.add('hidden');
  syncModalOpen();
}
$('#adminAccountsBtn').onclick = () => {
  if (!state?.isAdmin) return;
  $('#adminAccountsModal').classList.remove('hidden');
  syncModalOpen();
  loadAdminAccounts();
};
$('#closeAdminAccounts').onclick = closeAdminAccounts;
$('[data-close-admin-accounts]').onclick = closeAdminAccounts;
$('#refreshAdminAccounts').onclick = loadAdminAccounts;
$('#adminAccountSearch').oninput = renderAdminAccounts;
$('#adminAccountsModal').addEventListener('click', async e => {
  const btn = e.target.closest('button[data-admin-action]');
  if (!btn) return;
  const row = btn.closest('.adminAccountRow');
  const action = btn.dataset.adminAction;
  let path, payload;
  if (action === 'password') {
    const password = row.querySelector('.adminPasswordInput').value;
    if (password.length < 4 || password.length > 128) return toast('Пароль должен быть от 4 до 128 символов');
    if (!confirm('Сменить пароль этому аккаунту?')) return;
    path='/api/admin/account/update'; payload={accountId:Number(row.dataset.accountId),action:'password',password};
  } else {
    const amount = Number(row.querySelector('.adminBalanceInput').value);
    if (!Number.isSafeInteger(amount) || amount < 0 || amount > 1000000000) return toast('Введите целое число от 0 до 1 000 000 000');
    if (action === 'guest-balance') {
      path='/api/admin/guest/balance';
      payload={targetTableId:row.dataset.guestTable,playerId:row.dataset.guestId,amount};
    } else {
      path='/api/admin/account/update';
      payload={accountId:Number(row.dataset.accountId),action:'balance',amount};
    }
  }
  btn.disabled=true;
  try {
    await api(path,payload);
    toast(action==='password' ? 'Пароль обновлён' : 'Баланс сохранён');
    await loadAdminAccounts();
  } catch(err) { toast(err.message,4500); }
  finally { btn.disabled=false; }
});
