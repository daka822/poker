#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")" || exit 1
if ! command -v python >/dev/null 2>&1; then
  echo 'Python не найден. Сначала запустите: ./install_android.sh'
  exit 1
fi
if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock >/dev/null 2>&1 || true
  trap 'termux-wake-unlock >/dev/null 2>&1 || true' EXIT INT TERM
fi
# Открываем локальную панель хоста через пару секунд, если команда доступна.
if command -v termux-open-url >/dev/null 2>&1; then
  (sleep 2; termux-open-url "http://127.0.0.1:${PORT:-8080}/host.html" >/dev/null 2>&1 || true) &
fi
python server.py
